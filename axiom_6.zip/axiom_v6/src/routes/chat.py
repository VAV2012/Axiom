"""
routes/chat.py — POST /chat
Unified endpoint: ingest message → build context → call LLM → return response.
This is the primary consumer-facing endpoint.

v6 fixes
--------
FIX-1  Authorization bypass: body.user_id is now verified to belong to the
       authenticated tenant before any data access occurs.  Previously any
       valid API key could read/write any user's memories by passing an
       arbitrary UUID.

FIX-2  Streaming DB session: the _event_generator() closure inside
       chat_stream_endpoint() previously relied on the outer request-scoped
       DB session to persist the assistant reply.  With StreamingResponse,
       FastAPI keeps the dependency alive through the stream, but if an
       exception is caught inside the generator the rollback hook in get_db()
       is never triggered, leaving the session in an indeterminate state.
       The generator now opens its own dedicated session via AsyncSessionLocal
       so the write is isolated, explicit, and always committed or rolled back
       independently of the outer session.
"""
from __future__ import annotations

import json
import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

try:
    from slowapi import Limiter
    from slowapi.util import get_remote_address
    _limiter: Limiter | None = None
    def _get_limiter() -> Limiter | None:
        global _limiter
        return _limiter
    def set_limiter(limiter: Limiter) -> None:
        global _limiter
        _limiter = limiter
except ImportError:
    _get_limiter = lambda: None  # type: ignore
    set_limiter = lambda l: None  # type: ignore

from src.db.connection import get_db, AsyncSessionLocal
from src.db.models import User
from src.db.schemas import ChatRequest, ChatResponse, MemoryUsed
from src.middlewares.auth import require_api_key
from src.middlewares.error_handler import AppException
from src.services import memory as memory_svc
from src.services import context as context_svc
from src.services import model_router
from src.services import llm_client

router = APIRouter(prefix="/chat", tags=["chat"])


# ── FIX-1: tenant/user ownership guard ───────────────────────────────────────

async def _resolve_authed_user(
    db: AsyncSession,
    user_id: uuid.UUID,
    tenant_id: str,
) -> User:
    """
    Verify that user_id exists AND belongs to the authenticated tenant.

    Raises AppException(403) if the user is not found or belongs to a
    different tenant — preventing cross-tenant memory access.

    Note: users created before migration_v4 have tenant_id=NULL.  Those
    rows will fail this check (403) until backfilled.  Use the admin route
    to re-provision or set tenant_id directly:
        UPDATE users SET tenant_id = '<tid>' WHERE id = '<uid>';
    """
    stmt = select(User).where(
        User.id == user_id,
        User.tenant_id == tenant_id,
    )
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    if not user:
        raise AppException(403, "User not found or access denied for this tenant")
    return user


# ── System prompt builder ─────────────────────────────────────────────────────

def _build_system_prompt(ctx: dict, caller_system_prompt: str | None) -> str:
    """Construct the full system prompt by injecting memory context."""
    base = caller_system_prompt or "You are a helpful AI assistant with persistent memory."
    sections: list[str] = [base]

    top_memories = ctx.get("top_memories", [])
    if top_memories:
        memory_lines = "\n".join(f"- [{m.type}] {m.content}" for m in top_memories)
        sections.append(f"## What you remember about this user\n{memory_lines}")

    contradictions = ctx.get("contradictions", [])
    if contradictions and top_memories:
        mem_by_id = {str(m.id): m for m in top_memories}
        conflict_lines = []
        for c in contradictions:
            src = mem_by_id.get(c["source_id"])
            tgt = mem_by_id.get(c["target_id"])
            if src and tgt:
                conflict_lines.append(f'- "{src.content}" vs "{tgt.content}"')
            elif src:
                conflict_lines.append(f'- "{src.content}" contradicts memory {c["target_id"]}')
        if conflict_lines:
            sections.append(
                "## Memory conflicts detected\n"
                "The following memories may contradict each other — use the more recent or higher-confidence one:\n"
                + "\n".join(conflict_lines)
            )

    profile = ctx.get("profile", {})
    if profile:
        sections.append(f"## User profile\n{json.dumps(profile, indent=2)}")

    summaries = ctx.get("summaries", [])
    if summaries:
        sections.append("## Previous conversation summary\n" + "\n".join(summaries))

    sections.append(
        "Use the above context to give personalised, accurate responses.\n"
        "Do not mention that you have a memory system unless the user asks.\n"
        "Do not fabricate memories that are not listed above."
    )
    return "\n\n".join(sections)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("", response_model=ChatResponse)
async def chat_endpoint(
    request: Request,
    body: ChatRequest,
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    """
    Unified memory + LLM endpoint.

    1. Verify user belongs to authenticated tenant          ← FIX-1
    2. Store user message and run memory pipeline
    3. Build context (memories, profile, summaries)
    4. Select model via complexity classifier
    5. Call LLM with injected context
    6. Store assistant reply
    7. Return structured response
    """
    logger.debug(
        f"[Chat] tenant={tenant} user={body.user_id} session={body.session_id} "
        f"msg_len={len(body.message)}"
    )

    # 1. FIX-1 — reject mismatched or forged user IDs before touching any data
    await _resolve_authed_user(db, body.user_id, tenant)

    # 2. Ingest user message + memory pipeline
    _, memories_created, memories_updated = await memory_svc.process_message(
        db=db,
        user_id=body.user_id,
        session_id=body.session_id,
        content=body.message,
        role="user",
    )

    # 3. Build context
    ctx = await context_svc.build_context(
        db, body.user_id, body.session_id, query=body.message
    )

    # 4. Build system prompt
    system_prompt_str = _build_system_prompt(ctx, caller_system_prompt=body.system_prompt)

    # 5. Select model via complexity router
    model, complexity = await model_router.select_model(body.message, ctx)
    logger.info(f"[Chat] complexity={complexity} model={model}")

    # 6. Call LLM
    reply = await llm_client.chat(
        model=model,
        system=system_prompt_str,
        user=body.message,
        recent_messages=ctx["recent_messages"],
    )

    # 7. Store assistant reply (no memory extraction for assistant turns)
    await memory_svc.process_message(
        db=db,
        user_id=body.user_id,
        session_id=body.session_id,
        content=reply,
        role="assistant",
    )

    memories_used = [
        MemoryUsed(id=m.id, type=m.type, content=m.content, score=m.score)
        for m in ctx.get("top_memories", [])
    ]
    graph_additions = ctx.get("graph_additions", 0)
    contradictions_detected = len(ctx.get("contradictions", []))

    logger.info(
        f"[Chat] reply_len={len(reply)} memories_used={len(memories_used)} "
        f"graph_additions={graph_additions} contradictions={contradictions_detected}"
    )

    return ChatResponse(
        reply=reply,
        model_used=model,
        complexity=complexity,
        memories_used=memories_used,
        graph_additions=graph_additions,
        contradictions_detected=contradictions_detected,
        memories_created=memories_created,
        memories_updated=memories_updated,
        session_id=body.session_id,
    )


@router.post("/stream")
async def chat_stream_endpoint(
    request: Request,
    body: ChatRequest,
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    """
    Streaming SSE endpoint (FIX-1 + FIX-2).

    Same pipeline as POST /chat but streams tokens in real time.
    Format:
        data: {"delta": "token", "done": false}\\n\\n
        data: {"delta": "", "done": true, "model_used": "...", ...}\\n\\n

    The assembled reply is stored via a dedicated DB session (FIX-2) that is
    independent of the outer request-scoped session.
    """
    logger.debug(
        f"[ChatStream] tenant={tenant} user={body.user_id} session={body.session_id}"
    )

    # FIX-1 — verify ownership first
    await _resolve_authed_user(db, body.user_id, tenant)

    # Ingest user message + memory pipeline
    _, memories_created, memories_updated = await memory_svc.process_message(
        db=db,
        user_id=body.user_id,
        session_id=body.session_id,
        content=body.message,
        role="user",
    )

    # Build context
    ctx = await context_svc.build_context(
        db, body.user_id, body.session_id, query=body.message
    )

    system_prompt_str = _build_system_prompt(ctx, caller_system_prompt=body.system_prompt)
    model, complexity = await model_router.select_model(body.message, ctx)
    logger.info(f"[ChatStream] complexity={complexity} model={model}")

    memories_used = [
        MemoryUsed(id=m.id, type=m.type, content=m.content, score=m.score)
        for m in ctx.get("top_memories", [])
    ]
    graph_additions    = ctx.get("graph_additions", 0)
    contradictions_det = len(ctx.get("contradictions", []))
    recent_msgs        = ctx.get("recent_messages", [])

    # Capture primitives for the closure — do not capture db or ctx
    _user_id    = body.user_id
    _session_id = body.session_id

    async def _event_generator():
        assembled_tokens: list[str] = []

        try:
            async for token in llm_client.chat_stream(
                model=model,
                system=system_prompt_str,
                user=body.message,
                recent_messages=recent_msgs,
            ):
                assembled_tokens.append(token)
                payload = json.dumps({"delta": token, "done": False})
                yield f"data: {payload}\n\n"

            full_reply = "".join(assembled_tokens)

            final = json.dumps({
                "delta":                   "",
                "done":                    True,
                "model_used":              model,
                "complexity":              complexity,
                "memories_used":           [m.dict() for m in memories_used],
                "session_id":              str(_session_id),
                "graph_additions":         graph_additions,
                "contradictions_detected": contradictions_det,
                "memories_created":        memories_created,
                "memories_updated":        memories_updated,
            })
            yield f"data: {final}\n\n"

            # FIX-2: dedicated session for the assistant reply.
            # Never reuse the outer `db` here — it may already be committed,
            # rolled back, or in a partial state by the time streaming ends.
            async with AsyncSessionLocal() as store_db:
                try:
                    await memory_svc.process_message(
                        db=store_db,
                        user_id=_user_id,
                        session_id=_session_id,
                        content=full_reply,
                        role="assistant",
                    )
                    await store_db.commit()
                except Exception as store_exc:
                    await store_db.rollback()
                    logger.error(
                        f"[ChatStream] Failed to persist assistant reply: {store_exc}"
                    )

        except Exception as exc:
            logger.error(f"[ChatStream] Error during streaming: {exc}")
            err_payload = json.dumps({"error": str(exc), "done": True})
            yield f"data: {err_payload}\n\n"

    return StreamingResponse(
        _event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
