"""
decay.service — Upgraded memory decay with type-aware protection.

Upgrade vs v1
-------------
1. Identity memories are never archived by decay (protected type)
2. Low-confidence memories decay faster (confidence field integration)
3. Decay run checks time since last run to avoid redundant DB writes
4. Passes memory_type to is_below_decay_threshold for identity protection
5. Logs decay by type for observability

v6 fix (FIX-7)
--------------
The v5 time-gate used a module-level `_last_decay_run` global (datetime | None).
In a multi-worker deployment every Gunicorn/uvicorn worker has its own copy of
this variable, so the 6-hour guard was applied per-process rather than globally:
  - 4 workers = decay ran up to 4× as often as intended
  - Worker restart = guard reset to None = immediate re-run regardless of last run

Fix: last-run timestamp is now stored in the `system_meta` DB table.
All workers read the same record; the timestamp survives restarts.

Called by: jobs/decay_job.py
"""

from datetime import datetime, timezone, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from src.db.models import Memory, SystemMeta
from src.services import ranking as ranking_svc
from src.utils.scoring import is_below_decay_threshold

# Minimum real-world time between decay runs that actually writes to DB.
# Scoring is day-granularity — running every hour is 24× wasted compute.
_DECAY_MIN_INTERVAL_HOURS = 6
_DECAY_LAST_RUN_KEY = "decay_last_run"


# ── FIX-7: DB-backed last-run helpers ────────────────────────────────────────

async def _get_last_run(db: AsyncSession) -> datetime | None:
    """Read the last decay run timestamp from system_meta (shared across workers)."""
    stmt = select(SystemMeta).where(SystemMeta.key == _DECAY_LAST_RUN_KEY)
    result = await db.execute(stmt)
    row = result.scalar_one_or_none()
    if row and row.value:
        try:
            dt = datetime.fromisoformat(row.value)
            # Ensure timezone-aware
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    return None


async def _set_last_run(db: AsyncSession, dt: datetime) -> None:
    """Upsert the decay last-run timestamp into system_meta."""
    stmt = select(SystemMeta).where(SystemMeta.key == _DECAY_LAST_RUN_KEY)
    result = await db.execute(stmt)
    row = result.scalar_one_or_none()
    if row:
        row.value = dt.isoformat()
    else:
        db.add(SystemMeta(key=_DECAY_LAST_RUN_KEY, value=dt.isoformat()))
    await db.flush()


# ── Main decay run ────────────────────────────────────────────────────────────

async def run_decay(db: AsyncSession) -> dict:
    """
    Rescore all active memories; archive those below the decay threshold.

    FIX-7: Time-gate now reads from the DB (system_meta) so all workers
    share the same last-run timestamp and the check survives restarts.
    """
    now = datetime.now(timezone.utc)

    last_run = await _get_last_run(db)
    if last_run is not None:
        elapsed_hours = (now - last_run).total_seconds() / 3600
        if elapsed_hours < _DECAY_MIN_INTERVAL_HOURS:
            logger.debug(
                f"[Decay] Skipped — last run {elapsed_hours:.1f}h ago "
                f"(min interval {_DECAY_MIN_INTERVAL_HOURS}h)"
            )
            return {"skipped": True, "hours_since_last": round(elapsed_hours, 1)}

    stmt = select(Memory).where(Memory.is_archived == False)
    result = await db.execute(stmt)
    memories: list[Memory] = list(result.scalars().all())

    rescored = 0
    archived = 0
    protected = 0
    stats_by_type: dict[str, int] = {}

    for mem in memories:
        old_score = mem.score
        mem.score = ranking_svc.score_memory(mem)
        rescored += 1

        # Type-aware threshold check — identity memories are never auto-archived
        if is_below_decay_threshold(mem.score, memory_type=mem.type):
            mem.is_archived = True
            archived += 1
            stats_by_type[mem.type] = stats_by_type.get(mem.type, 0) + 1
            logger.info(
                f"[Decay] Archived {mem.type} memory {mem.id!s:.8} "
                f"(score {old_score:.4f} → {mem.score:.4f})"
            )
        elif mem.type == "identity" and mem.score < 0.30:
            # Log but do NOT archive — identity is protected
            protected += 1
            logger.debug(
                f"[Decay] Identity memory {mem.id!s:.8} score={mem.score:.4f} "
                f"(low but protected)"
            )

    await db.flush()

    # FIX-7: persist the new last-run time to DB so other workers see it
    await _set_last_run(db, datetime.now(timezone.utc))
    await db.flush()

    logger.info(
        f"[Decay] Rescored {rescored} | Archived {archived} | Protected {protected} "
        f"| By type: {stats_by_type}"
    )
    return {
        "rescored": rescored,
        "archived": archived,
        "protected": protected,
        "archived_by_type": stats_by_type,
    }
