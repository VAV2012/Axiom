"""
evolution.service — Smarter contradiction detection, routing, and resolution.

Upgrade vs v1
-------------
v1 had a single threshold and always replaced. This version:

1. Three-band similarity routing:
   - sim < 0.75         → CREATE (independent memory)
   - 0.75 ≤ sim < 0.88  → LINK as "supports" / "refines" (additive)
   - 0.88 ≤ sim < 0.96  → MERGE or VERSION (type-dependent)
   - sim ≥ 0.96         → REPLACE with versioning

2. Type-aware strategies:
   - identity   → always MERGE (never destroy who someone is)
   - event/past → always CREATE (past events don't contradict)
   - constraint → REPLACE (dietary/medical must be current)
   - goal/pref  → VERSION (evolution, not overwrite)
   - fact       → REPLACE
   - habit      → MERGE if additive, VERSION if reversed

3. MemoryLink is actually written (v1 had it in the docstring but not the code)

4. Reinforcement and frequency are carried forward on REPLACE (partial credit)

5. Negation detection for habit reversal (e.g., "stopped exercising")

Evolution decision returned as a typed result dict so memory.service can
log and react to the strategy chosen.
"""

from datetime import datetime, timezone
from typing import Literal
import math
import uuid

from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from src.db.models import Memory, MemoryLink, MemoryVersion
from src.services import embedding as embedding_svc
from src.services import ranking as ranking_svc
from src.utils.scoring import get_importance_weight, get_decay_rate
from src.config.settings import get_settings

settings = get_settings()

# Similarity band boundaries
SIM_LINK_MIN   = 0.75   # below this → independent (CREATE)
SIM_MERGE_MIN  = 0.88   # below this (but above LINK_MIN) → LINK
SIM_REPLACE_MIN = 0.96  # above this → hard REPLACE

# Negation signals for habit reversal detection
NEGATION_SIGNALS = [
    "stopped", "quit", "no longer", "doesn't anymore", "gave up",
    "stopped doing", "ended", "not anymore", "dropped the habit",
]

Strategy = Literal["create", "link", "merge", "version", "replace"]


def _l2_normalize(v: list[float]) -> list[float]:
    """
    FIX-5: Return the L2-normalised copy of a vector.

    An element-wise average of two unit vectors is NOT itself a unit vector —
    its norm is cos(θ/2) where θ is the angle between them.  Storing a
    sub-unit embedding means future in-memory _dot() calls (which assume
    pre-normalised vectors) return lower cosine similarities than pgvector
    does, causing the redundancy filter in context.service to behave
    inconsistently.  Normalising after averaging removes the drift.
    """
    norm = math.sqrt(sum(x * x for x in v))
    return [x / norm for x in v] if norm > 0 else v


def _detect_negation(content: str) -> bool:
    """Return True if the content signals a reversal/negation of a behaviour."""
    lower = content.lower()
    return any(sig in lower for sig in NEGATION_SIGNALS)


def _is_past_event(content: str) -> bool:
    """Heuristic: event content referencing the past should be additive."""
    past_signals = ["visited", "attended", "completed", "finished", "graduated",
                    "in 20", "last year", "last month", "ago", "back in"]
    lower = content.lower()
    return any(sig in lower for sig in past_signals)


def choose_strategy(
    sim: float,
    existing_type: str,
    new_content: str,
) -> Strategy:
    """
    Route to the correct evolution strategy based on similarity band + type rules.

    Returns one of: "create", "link", "merge", "version", "replace"
    """
    # Band 1: clearly different topic
    if sim < SIM_LINK_MIN:
        return "create"

    # Band 2: related but not conflicting — link additively
    if sim < SIM_MERGE_MIN:
        return "link"

    # Band 3: clear conflict or update
    if sim < SIM_REPLACE_MIN:
        # Type-specific routing within the merge/version band
        if existing_type == "identity":
            return "merge"          # identity info compounds, never overwrites
        if existing_type == "constraint":
            return "replace"        # constraints must be current (allergies, etc.)
        if existing_type == "fact":
            return "replace"        # facts don't co-exist if contradictory
        if existing_type == "event":
            if _is_past_event(new_content):
                return "create"     # past events are additive
            return "replace"        # future event updates
        if existing_type == "goal":
            return "version"        # goals evolve, keep history
        if existing_type == "preference":
            return "version"        # preference shift, keep history
        if existing_type == "habit":
            if _detect_negation(new_content):
                return "version"    # habit reversal → version (not just merge)
            return "merge"          # habit refinement → merge

    # Band 4: near-identical — hard replace
    return "replace"


def find_contradiction(
    existing: list[Memory],
    new_embedding: list[float],
) -> tuple[Memory | None, float]:
    """
    Scan active memories for the best similarity match above SIM_LINK_MIN.
    Returns (best_match, similarity) or (None, 0.0).

    Upgrade: returns the similarity score so callers can make routing decisions.
    v1 returned only the Memory (callers couldn't see the sim score).
    """
    best_mem = None
    best_sim = 0.0

    for mem in existing:
        if mem.embedding is None or mem.is_archived:
            continue
        sim = embedding_svc.cosine_similarity(new_embedding, mem.embedding)
        if sim >= SIM_LINK_MIN and sim > best_sim:
            best_sim = sim
            best_mem = mem

    return best_mem, best_sim


async def resolve_evolution(
    db: AsyncSession,
    existing: Memory,
    new_content: str,
    new_embedding: list[float],
    new_type: str,
    sim: float,
    confidence: float = 0.8,
    source_message_id: uuid.UUID | None = None,  # FIX-8: current message ID
) -> tuple[Memory, Strategy]:
    """
    Apply the correct evolution strategy and return (updated_memory, strategy_used).

    source_message_id should be the ID of the message that triggered this
    evolution — not the original message that created `existing`.  This is
    forwarded to _strategy_version so the new Memory row is attributed to
    the message that actually produced its content.
    """
    strategy = choose_strategy(sim, existing.type, new_content)

    if strategy == "link":
        await _strategy_link(db, existing, new_content, new_embedding, sim)
        return existing, strategy

    if strategy == "merge":
        return await _strategy_merge(db, existing, new_content, new_embedding, new_type, confidence), strategy

    if strategy == "version":
        new_mem = await _strategy_version(
            db, existing, new_content, new_embedding, new_type, confidence,
            source_message_id=source_message_id,  # FIX-8
        )
        return new_mem, strategy

    if strategy == "replace":
        return await _strategy_replace(db, existing, new_content, new_embedding, new_type, confidence), strategy

    # "create" should not reach here — caller handles it
    return existing, strategy


# ── Strategy implementations ─────────────────────────────────────────────────

async def _strategy_link(
    db: AsyncSession,
    existing: Memory,
    new_content: str,
    new_embedding: list[float],
    sim: float,
) -> None:
    """
    LINK: New memory supports/refines existing. No overwrite.
    Just create a MemoryLink with strength proportional to similarity.
    The new memory will be created normally by the caller.
    """
    # We don't have the new Memory object yet — the caller will create it.
    # We write a placeholder link record after creation via memory.service.
    # Here we just log the intent and let the caller handle link creation.
    logger.debug(
        f"[Evolution] LINK strategy: existing={existing.id!s:.8} "
        f"sim={sim:.3f} — new memory will be linked as 'supports'"
    )


async def _strategy_merge(
    db: AsyncSession,
    existing: Memory,
    new_content: str,
    new_embedding: list[float],
    new_type: str,
    confidence: float,
) -> Memory:
    """
    MERGE: Append new info to existing memory. Keep existing as primary.
    Average the embeddings. Increment frequency.
    Write MemoryLink(relation_type="refines").
    """
    # Snapshot before mutation
    _snapshot(db, existing, reason="merge")

    # Append new content as a parenthetical if not already present
    if new_content.lower() not in existing.content.lower():
        merged_content = f"{existing.content} ({new_content})"
    else:
        merged_content = existing.content  # already covered

    # Average embeddings then re-normalise for correct cosine geometry.
    # FIX-5: the element-wise mean of two unit vectors is NOT a unit vector;
    # storing an un-normalised embedding causes _dot() in context.service
    # (which assumes unit vectors) to underestimate similarity scores.
    if existing.embedding and new_embedding:
        avg_raw = [(a + b) / 2 for a, b in zip(existing.embedding, new_embedding)]
        existing.embedding = _l2_normalize(avg_raw)

    existing.content         = merged_content
    existing.frequency      += 1
    existing.last_accessed_at = datetime.now(timezone.utc)
    existing.score           = ranking_svc.score_memory(existing)

    await db.flush()

    logger.info(
        f"[Evolution] MERGE: memory {existing.id!s:.8} → '{merged_content[:80]}…'"
    )
    return existing


async def _strategy_version(
    db: AsyncSession,
    existing: Memory,
    new_content: str,
    new_embedding: list[float],
    new_type: str,
    confidence: float,
    source_message_id: uuid.UUID | None = None,  # FIX-8
) -> Memory:
    """
    VERSION: Goal/preference evolved. Snapshot old, create new Memory.
    Write MemoryLink(old → new, "superseded_by").
    The old memory is archived; the new one is the live truth.

    FIX-8: source_message_id now refers to the message that triggered this
    evolution (the current turn), not the original message that created
    `existing`.  Using existing.source_message_id was wrong because the new
    memory's content comes from the current message, not the original one.
    """
    _snapshot(db, existing, reason="evolved")

    # Archive the old one — it's superseded, not deleted
    existing.is_archived = True
    await db.flush()

    # Build new Memory attributed to the current message
    from src.db.models import Memory as MemoryModel  # avoid circular at module level
    new_mem = MemoryModel(
        user_id=existing.user_id,
        source_message_id=source_message_id,  # FIX-8: current message, not the old one
        type=new_type,
        content=new_content,
        embedding=new_embedding,
        importance=get_importance_weight(new_type) * confidence,
        decay_rate=get_decay_rate(new_type),
        frequency=1,
        reinforcement=existing.reinforcement * 0.3,  # partial credit from predecessor
    )
    db.add(new_mem)
    await db.flush()

    # Link: old → new
    link = MemoryLink(
        source_id=existing.id,
        target_id=new_mem.id,
        relation_type="superseded_by",
        strength=1.0,
    )
    db.add(link)
    await db.flush()

    new_mem.score = ranking_svc.score_memory(new_mem)
    await db.flush()

    logger.info(
        f"[Evolution] VERSION: memory {existing.id!s:.8} → archived, "
        f"new {new_mem.id!s:.8} created ('{new_content[:60]}…')"
    )
    return new_mem


async def _strategy_replace(
    db: AsyncSession,
    existing: Memory,
    new_content: str,
    new_embedding: list[float],
    new_type: str,
    confidence: float,
) -> Memory:
    """
    REPLACE: Clear update. Snapshot old, overwrite in place.
    Carry forward partial frequency + reinforcement credit.

    FIX-4: v5 constructed a MemoryLink object here but never called db.add()
    on it, so no contradiction link was ever written to the database.  The
    comment said "we skip the self-link and rely on MemoryVersion" — the
    MemoryVersion snapshot IS the full audit trail for a REPLACE, so no
    MemoryLink is needed here.  The dead object construction has been removed
    to avoid misleading future readers.
    """
    # Snapshot before mutation — this IS the audit trail for a REPLACE event
    _snapshot(db, existing, reason="contradiction")

    existing.content          = new_content
    existing.embedding        = new_embedding
    existing.type             = new_type
    existing.importance       = get_importance_weight(new_type) * confidence
    existing.decay_rate       = get_decay_rate(new_type)
    existing.frequency       += 1                              # carry forward
    existing.reinforcement    = existing.reinforcement * 0.5   # partial credit
    existing.version         += 1
    existing.last_accessed_at = datetime.now(timezone.utc)
    existing.is_archived      = False
    existing.score            = ranking_svc.score_memory(existing)

    await db.flush()

    logger.info(
        f"[Evolution] REPLACE: memory {existing.id!s:.8} → v{existing.version} "
        f"('{new_content[:60]}…')"
    )
    return existing


def _snapshot(db: AsyncSession, memory: Memory, reason: str) -> MemoryVersion:
    """Write a MemoryVersion snapshot before any mutation."""
    version = MemoryVersion(
        memory_id=memory.id,
        version=memory.version,
        content=memory.content,
        type=memory.type,
        score=memory.score,
        reason=reason,
    )
    db.add(version)
    return version
