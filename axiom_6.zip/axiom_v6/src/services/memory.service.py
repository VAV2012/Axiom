"""
memory.service — Upgraded orchestrator for the full memory lifecycle.

Flow (on user message)
----------------------
extract → (pre-dedup check) → embed → find_contradiction + choose_strategy
       → evolve (merge/version/replace/link) OR create → score → sync profile

Upgrade vs v1
-------------
1. Passes existing memory contents to extract_memories for pre-LLM dedup
2. Uses resolve_evolution() (not resolve_contradiction()) — strategy-aware
3. Handles "link" and "version" strategies (v1 only had "replace")
4. After VERSION creates a new Memory, links old → new in memory_links
5. Passes confidence to Memory constructor (stored for scoring)
6. Returns richer observability dict (strategies used)
"""

import uuid
from datetime import datetime, timezone

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from src.db.models import Memory, MemoryLink, Message
from src.services import embedding as embedding_svc
from src.services import extraction as extraction_svc
from src.services import ranking as ranking_svc
from src.services import evolution as evolution_svc
from src.services import profile as profile_svc
from src.utils.scoring import get_importance_weight, get_decay_rate
from src.config.settings import get_settings

settings = get_settings()


# ─── Public entry point ───────────────────────────────────────────────────────

async def process_message(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
    content: str,
    role: str = "user",
) -> tuple[Message, int, int]:
    """
    Store a raw message and trigger memory extraction if role == 'user'.
    Returns (message, memories_created, memories_updated).
    """
    message = Message(
        user_id=user_id,
        session_id=session_id,
        role=role,
        content=content,
        token_count=len(content.split()),
        processed=False,
    )
    db.add(message)
    await db.flush()

    created = updated = 0

    if role == "user":
        existing = await get_user_memories(db, user_id)

        # Pass existing memory content for pre-LLM deduplication
        existing_contents = [m.content for m in existing]
        extracted = await extraction_svc.extract_memories(content, existing_contents)

        if extracted:
            created, updated = await _store_extracted_memories(
                db, user_id, message, extracted, existing
            )

        message.processed = True
        await db.flush()

        await profile_svc.sync_profile(db, user_id)

    logger.info(
        f"[Memory] Message {message.id!s:.8} | user={user_id!s:.8} | role={role} "
        f"| +{created} created | ~{updated} updated"
    )
    return message, created, updated


# ─── Internal ─────────────────────────────────────────────────────────────────

async def _store_extracted_memories(
    db: AsyncSession,
    user_id: uuid.UUID,
    message: Message,
    items: list[dict],
    existing: list[Memory],
) -> tuple[int, int]:
    created = updated = 0

    for item in items:
        mem_type   = item["type"]
        content    = item["content"]
        confidence = item.get("confidence", 0.7)
        importance = get_importance_weight(mem_type) * confidence
        decay_rate = get_decay_rate(mem_type)

        new_embedding = await embedding_svc.get_embedding(content)

        # find_contradiction now returns (memory, sim) — strategy-aware
        conflict, sim = evolution_svc.find_contradiction(existing, new_embedding)

        if conflict:
            updated_mem, strategy = await evolution_svc.resolve_evolution(
                db=db,
                existing=conflict,
                new_content=content,
                new_embedding=new_embedding,
                new_type=mem_type,
                sim=sim,
                confidence=confidence,
                source_message_id=message.id,  # FIX-8: pass current message so versioned memories are attributed correctly
            )

            if strategy == "version":
                # VERSION creates a new Memory — add to tracking list
                existing.append(updated_mem)
                created += 1
            elif strategy == "link":
                # LINK: create the new memory AND write the link
                new_mem = await _create_memory(
                    db, user_id, message, mem_type, content,
                    new_embedding, importance, decay_rate, confidence
                )
                existing.append(new_mem)
                # Write the MemoryLink now that we have both IDs
                link = MemoryLink(
                    source_id=new_mem.id,
                    target_id=conflict.id,
                    relation_type="supports",
                    strength=round(sim, 3),
                )
                db.add(link)
                await db.flush()
                created += 1
            else:
                # MERGE or REPLACE — existing memory was updated in place
                updated += 1
        else:
            # No conflict — create fresh memory
            new_mem = await _create_memory(
                db, user_id, message, mem_type, content,
                new_embedding, importance, decay_rate, confidence
            )
            existing.append(new_mem)
            created += 1

    await db.flush()
    return created, updated


async def _create_memory(
    db: AsyncSession,
    user_id: uuid.UUID,
    message: Message,
    mem_type: str,
    content: str,
    embedding: list[float],
    importance: float,
    decay_rate: float,
    confidence: float,
) -> Memory:
    """Create and persist a new Memory row."""
    mem = Memory(
        user_id=user_id,
        source_message_id=message.id,
        type=mem_type,
        content=content,
        embedding=embedding,
        importance=importance,
        decay_rate=decay_rate,
        frequency=1,
        reinforcement=0.0,
        # confidence stored via the column if you add it; otherwise pass to score
    )
    mem.score = ranking_svc.score_memory(mem)
    db.add(mem)
    await db.flush()
    return mem


# ─── Retrieval ────────────────────────────────────────────────────────────────

async def get_user_memories(
    db: AsyncSession,
    user_id: uuid.UUID,
    include_archived: bool = False,
) -> list[Memory]:
    # FIX-3: Previously the filter was `Memory.is_archived == (True if include_archived else False)`,
    # which when include_archived=True returned ONLY archived rows, not all rows.
    # Correct behaviour: include_archived=False → non-archived only (default);
    #                    include_archived=True  → all rows regardless of archive status.
    stmt = select(Memory).where(Memory.user_id == user_id)
    if not include_archived:
        stmt = stmt.where(Memory.is_archived == False)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_recent_messages(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
    limit: int | None = None,
) -> list[Message]:
    limit = limit or settings.short_term_window
    stmt = (
        select(Message)
        .where(and_(Message.user_id == user_id, Message.session_id == session_id))
        .order_by(Message.created_at.desc())
        .limit(limit)
    )
    result = await db.execute(stmt)
    return list(reversed(result.scalars().all()))


async def get_memory_by_id(
    db: AsyncSession,
    memory_id: uuid.UUID,
    user_id: uuid.UUID,
) -> Memory | None:
    stmt = select(Memory).where(and_(Memory.id == memory_id, Memory.user_id == user_id))
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def reinforce_memories(db: AsyncSession, memories: list[Memory]) -> None:
    """Boost reinforcement score for retrieved memories."""
    for mem in memories:
        ranking_svc.apply_reinforcement(mem, settings.reinforcement_boost)
        mem.last_accessed_at = datetime.now(timezone.utc)
    await db.flush()


# ─── Update / Delete ──────────────────────────────────────────────────────────

async def update_memory_content(
    db: AsyncSession,
    memory: Memory,
    new_content: str,
) -> Memory:
    memory.content          = new_content
    memory.embedding        = await embedding_svc.get_embedding(new_content)
    memory.last_accessed_at = datetime.now(timezone.utc)
    memory.score            = ranking_svc.score_memory(memory)
    await db.flush()
    return memory


async def archive_memory(db: AsyncSession, memory: Memory) -> Memory:
    memory.is_archived = True
    await db.flush()
    logger.info(f"[Memory] Archived memory {memory.id!s:.8}")
    return memory


async def delete_memory(db: AsyncSession, memory: Memory) -> None:
    await db.delete(memory)
    await db.flush()
    logger.info(f"[Memory] Deleted memory {memory.id!s:.8}")
