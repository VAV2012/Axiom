-- ============================================================
-- Migration v4 — Axiom Remember v5 → v6
--
-- Changes
-- -------
-- 1. users.tenant_id  — ties each user row to an API-key tenant so
--    the chat endpoint can verify body.user_id belongs to the caller.
--    Backfill: leave NULL for existing rows; populate via the admin
--    route when re-provisioning users under the correct tenant.
--
-- 2. system_meta table — DB-backed key/value store that replaces the
--    in-memory _last_decay_run global.  All workers share one record;
--    value survives restarts and horizontal scaling.
-- ============================================================

-- 1. Add tenant_id to users
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS tenant_id VARCHAR(255);

CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);

-- 2. Create system_meta
CREATE TABLE IF NOT EXISTS system_meta (
    key   VARCHAR(100) PRIMARY KEY,
    value TEXT
);
