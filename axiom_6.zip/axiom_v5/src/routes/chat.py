"""
routes/chat.py — POST /chat
Unified endpoint: ingest message → build context → call LLM → return response.
This is the primary consumer-facing endpoint.
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

try:
    from slowapi import Limiter
    from slowapi.util import get_remote_address
    _limiter: Limiter | None = None
    def _get_limiter() -> Limiter | None:
        global _limiter
        return _limiter
    def set_limiter(limiter: Limiter) -> None:
        global _limiter
        _limiter = limiter
except ImportError:
    _get_limiter = lambda: None  # type: ignore
    set_limiter = lambda l: None  # type: ignore

from src.db.connection import get_db
from src.db.schemas import ChatRequest, ChatResponse, MemoryUsed
from src.middlewares.auth import require_api_key
from src.middlewares.error_handler import AppException
from src.services import memory as memory_svc
from src.services import context as context_svc
from src.services import model_router
from src.services import llm_client
from src.services import llm_client as _llm

router = APIRouter(prefix="/chat", tags=["chat"])


def _build_system_prompt(ctx: dict, caller_system_prompt: str | None) -> str:
    """Construct the full system prompt by injecting memory context."""
    base = caller_system_prompt or "You are a helpful AI assistant with persistent memory."

    sections: list[str] = [base]

    # Memory section — top memories + graph additions
    top_memories = ctx.get("top_memories", [])
    if top_memories:
        memory_lines = "\n".join(
            f"- [{m.type}] {m.content}" for m in top_memories
        )
        sections.append(f"## What you remember about this user\n{memory_lines}")

    # Contradiction section
    contradictions = ctx.get("contradictions", [])
    if contradictions and top_memories:
        # Build a map from id → content for quick lookup
        mem_by_id = {str(m.id): m for m in top_memories}
        conflict_lines = []
        for c in contradictions:
            src = mem_by_id.get(c["source_id"])
            tgt = mem_by_id.get(c["target_id"])
            if src and tgt:
                conflict_lines.append(f"- \"{src.content}\" vs \"{tgt.content}\"")
            elif src:
                conflict_lines.append(f"- \"{src.content}\" contradicts memory {c['target_id']}")
        if conflict_lines:
            sections.append(
                "## Memory conflicts detected\n"
                "The following memories may contradict each other — use the more recent or higher-confidence one:\n"
                + "\n".join(conflict_lines)
            )

    # Profile section
    profile = ctx.get("profile", {})
    if profile:
        sections.append(f"## User profile\n{json.dumps(profile, indent=2)}")

    # Summary section
    summaries = ctx.get("summaries", [])
    if summaries:
        sections.append("## Previous conversation summary\n" + "\n".join(summaries))

    # Instruction
    sections.append(
        "Use the above context to give personalised, accurate responses.\n"
        "Do not mention that you have a memory system unless the user asks.\n"
        "Do not fabricate memories that are not listed above."
    )

    return "\n\n".join(sections)


@router.post("", response_model=ChatResponse)
async def chat_endpoint(
    request: Request,
    body: ChatRequest,
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    """
    Unified memory + LLM endpoint.

    1. Store user message and run memory pipeline
    2. Build context (memories, profile, summaries)
    3. Select model via complexity classifier
    4. Call LLM with injected context
    5. Store assistant reply
    6. Return structured response
    """
    logger.debug(
        f"[Chat] tenant={tenant} user={body.user_id} session={body.session_id} "
        f"msg_len={len(body.message)}"
    )

    # 1. Ingest user message + memory pipeline
    _, memories_created, memories_updated = await memory_svc.process_message(
        db=db,
        user_id=body.user_id,
        session_id=body.session_id,
        content=body.message,
        role="user",
    )

    # 2. Build context
    ctx = await context_svc.build_context(
        db, body.user_id, body.session_id, query=body.message
    )

    # 3. Build system prompt
    system_prompt_str = _build_system_prompt(ctx, caller_system_prompt=body.system_prompt)

    # 4. Select model via complexity router
    model, complexity = await model_router.select_model(body.message, ctx)
    logger.info(f"[Chat] complexity={complexity} model={model}")

    # 5. Call LLM
    reply = await llm_client.chat(
        model=model,
        system=system_prompt_str,
        user=body.message,
        recent_messages=ctx["recent_messages"],
    )

    # 6. Store assistant reply (no memory extraction for assistant turns)
    await memory_svc.process_message(
        db=db,
        user_id=body.user_id,
        session_id=body.session_id,
        content=reply,
        role="assistant",
    )

    # 7. Build memories_used list from top_memories in context
    memories_used = [
        MemoryUsed(id=m.id, type=m.type, content=m.content, score=m.score)
        for m in ctx.get("top_memories", [])
    ]

    graph_additions = ctx.get("graph_additions", 0)
    contradictions_detected = len(ctx.get("contradictions", []))

    logger.info(
        f"[Chat] reply_len={len(reply)} memories_used={len(memories_used)} "
        f"graph_additions={graph_additions} contradictions={contradictions_detected}"
    )

    return ChatResponse(
        reply=reply,
        model_used=model,
        complexity=complexity,
        memories_used=memories_used,
        graph_additions=graph_additions,
        contradictions_detected=contradictions_detected,
        memories_created=memories_created,
        memories_updated=memories_updated,
        session_id=body.session_id,
    )


@router.post("/stream")
async def chat_stream_endpoint(
    request: Request,
    body: ChatRequest,
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    """
    Feature 3 — Streaming SSE endpoint.

    Same pipeline as POST /chat but streams tokens in real time using
    Server-Sent Events. Format:
        data: {"delta": "token", "done": false}\n\n
        data: {"delta": "", "done": true, "model_used": "...", ...}\n\n

    After all tokens are yielded the assembled reply is stored in memory
    (same as the non-streaming endpoint).
    """
    logger.debug(
        f"[ChatStream] tenant={tenant} user={body.user_id} session={body.session_id}"
    )

    # 1. Ingest user message + memory pipeline
    _, memories_created, memories_updated = await memory_svc.process_message(
        db=db,
        user_id=body.user_id,
        session_id=body.session_id,
        content=body.message,
        role="user",
    )

    # 2. Build context
    ctx = await context_svc.build_context(
        db, body.user_id, body.session_id, query=body.message
    )

    # 3. Build system prompt
    system_prompt_str = _build_system_prompt(ctx, caller_system_prompt=body.system_prompt)

    # 4. Select model
    model, complexity = await model_router.select_model(body.message, ctx)
    logger.info(f"[ChatStream] complexity={complexity} model={model}")

    # Snapshot for SSE final frame
    memories_used = [
        MemoryUsed(id=m.id, type=m.type, content=m.content, score=m.score)
        for m in ctx.get("top_memories", [])
    ]
    graph_additions    = ctx.get("graph_additions", 0)
    contradictions_det = len(ctx.get("contradictions", []))
    recent_msgs        = ctx.get("recent_messages", [])

    async def _event_generator():
        assembled_tokens: list[str] = []

        try:
            async for token in llm_client.chat_stream(
                model=model,
                system=system_prompt_str,
                user=body.message,
                recent_messages=recent_msgs,
            ):
                assembled_tokens.append(token)
                payload = json.dumps({"delta": token, "done": False})
                yield f"data: {payload}\n\n"

            # Final frame with metadata
            full_reply = "".join(assembled_tokens)
            final = json.dumps({
                "delta":                  "",
                "done":                   True,
                "model_used":             model,
                "complexity":             complexity,
                "memories_used":          [m.dict() for m in memories_used],
                "session_id":             body.session_id,
                "graph_additions":        graph_additions,
                "contradictions_detected": contradictions_det,
                "memories_created":       memories_created,
                "memories_updated":       memories_updated,
            })
            yield f"data: {final}\n\n"

            # Store assistant reply after streaming completes
            await memory_svc.process_message(
                db=db,
                user_id=body.user_id,
                session_id=body.session_id,
                content=full_reply,
                role="assistant",
            )

        except Exception as exc:
            logger.error(f"[ChatStream] Error during streaming: {exc}")
            err_payload = json.dumps({"error": str(exc), "done": True})
            yield f"data: {err_payload}\n\n"

    return StreamingResponse(
        _event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":               "no-cache",
            "X-Accel-Buffering":           "no",
        },
    )

