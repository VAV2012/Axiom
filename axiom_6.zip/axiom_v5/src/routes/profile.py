import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.connection import get_db
from src.db.schemas import ProfileResponse
from src.middlewares.error_handler import AppException
from src.middlewares.auth import require_api_key
from src.services import profile as profile_svc

router = APIRouter(prefix="/profile", tags=["profile"])


@router.get("", response_model=ProfileResponse)
async def get_profile(
    user_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    try:
        uid = uuid.UUID(user_id)
    except ValueError:
        raise AppException(400, "Invalid user_id UUID")

    profile = await profile_svc.get_profile(db, uid)
    if not profile:
        raise AppException(404, "Profile not found — send some messages first")

    data = profile.data
    return ProfileResponse(
        user_id=uid,
        identity=data.get("identity", {}),
        preferences=data.get("preferences", {}),
        goals=data.get("goals", []),
        habits=data.get("habits", []),
        constraints=data.get("constraints", []),
        updated_at=profile.updated_at,
    )
