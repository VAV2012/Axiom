"""
routes/admin.py — Internal admin endpoints.
Protected by AXIOM_ADMIN_SECRET env var (not the same as user API keys).
"""
import hashlib
import hmac
import secrets
import uuid

from fastapi import APIRouter, Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from loguru import logger

from src.db.connection import get_db
from src.db.models import ApiKey
from src.db.schemas import ApiKeyCreate, ApiKeyCreated, ApiKeyRead
from src.middlewares.error_handler import AppException
from src.config.settings import get_settings

settings = get_settings()

router = APIRouter(prefix="/admin", tags=["admin"])


async def _require_admin(x_admin_secret: str = Header(..., alias="x-admin-secret")) -> None:
    """Constant-time comparison to prevent timing attacks."""
    if not hmac.compare_digest(x_admin_secret, settings.admin_secret):
        raise AppException(403, "Invalid admin secret")


@router.post("/api-keys", response_model=ApiKeyCreated, status_code=201)
async def create_api_key(
    body: ApiKeyCreate,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(_require_admin),
):
    """
    Create a new API key for a tenant.
    The raw key is returned ONCE and never stored — only the SHA-256 hash is persisted.
    """
    # Generate raw key: "axm_" prefix + 40 random hex chars
    raw_key = "axm_" + secrets.token_hex(20)
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

    api_key = ApiKey(
        key_hash=key_hash,
        name=body.name,
        tenant_id=body.tenant_id,
    )
    db.add(api_key)
    await db.flush()

    logger.warning(f"[Admin] API key created for tenant={body.tenant_id} name={body.name} id={api_key.id}")

    return ApiKeyCreated(
        key=raw_key,
        id=api_key.id,
        name=api_key.name,
        tenant_id=api_key.tenant_id,
        created_at=api_key.created_at,
    )


@router.get("/api-keys", response_model=list[ApiKeyRead])
async def list_api_keys(
    db: AsyncSession = Depends(get_db),
    _: None = Depends(_require_admin),
):
    """List all API keys (hashes are never exposed)."""
    stmt = select(ApiKey).order_by(ApiKey.created_at.desc())
    result = await db.execute(stmt)
    keys = result.scalars().all()
    return [
        ApiKeyRead(
            id=k.id,
            name=k.name,
            tenant_id=k.tenant_id,
            is_active=k.is_active,
            created_at=k.created_at,
            last_used_at=k.last_used_at,
        )
        for k in keys
    ]


@router.patch("/api-keys/{key_id}/deactivate", status_code=200)
async def deactivate_api_key(
    key_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(_require_admin),
):
    """Deactivate an API key without deleting it (audit trail preserved)."""
    stmt = select(ApiKey).where(ApiKey.id == key_id)
    result = await db.execute(stmt)
    api_key = result.scalar_one_or_none()

    if not api_key:
        raise AppException(404, "API key not found")

    api_key.is_active = False
    await db.flush()

    logger.warning(f"[Admin] API key deactivated id={key_id} tenant={api_key.tenant_id}")
    return {"id": str(key_id), "is_active": False}
