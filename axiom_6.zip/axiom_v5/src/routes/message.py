"""
routes/message.py + controller logic — POST /message, GET /context
"""

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.connection import get_db
from src.db.schemas import MessageCreate, ProcessMessageResponse, ContextResponse
from src.middlewares.error_handler import AppException
from src.middlewares.auth import require_api_key
from src.services import memory as memory_svc
from src.services import context as context_svc

router = APIRouter(prefix="/message", tags=["messages"])


@router.post("", response_model=ProcessMessageResponse)
async def ingest_message(
    body: MessageCreate,
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    """Store a message and trigger the full memory pipeline."""
    message, created, updated = await memory_svc.process_message(
        db=db,
        user_id=body.user_id,
        session_id=body.session_id,
        content=body.content,
        role=body.role,
    )
    return ProcessMessageResponse(
        message=message,
        memories_created=created,
        memories_updated=updated,
    )


@router.get("/context", response_model=ContextResponse)
async def get_context(
    user_id: str = Query(...),
    session_id: str = Query(...),
    query: str | None = Query(None, description="Optional semantic query to bias retrieval"),
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    """Return an optimised context payload for the LLM."""
    import uuid
    try:
        uid = uuid.UUID(user_id)
        sid = uuid.UUID(session_id)
    except ValueError:
        raise AppException(400, "Invalid UUID format")

    ctx = await context_svc.build_context(db, uid, sid, query=query)
    return ContextResponse(
        user_id=uid,
        session_id=sid,
        recent_messages=ctx["recent_messages"],
        top_memories=ctx["top_memories"],
        summaries=ctx["summaries"],
        profile=ctx["profile"],
    )
