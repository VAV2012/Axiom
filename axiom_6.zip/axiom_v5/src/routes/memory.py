import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.connection import get_db
from src.db.schemas import MemoryListResponse, MemoryRead, MemoryUpdate
from src.middlewares.error_handler import AppException
from src.middlewares.auth import require_api_key
from src.services import memory as memory_svc
from src.services import ranking as ranking_svc

router = APIRouter(prefix="/memory", tags=["memory"])


@router.get("", response_model=MemoryListResponse)
async def list_memories(
    user_id: str = Query(...),
    include_archived: bool = Query(False),
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    try:
        uid = uuid.UUID(user_id)
    except ValueError:
        raise AppException(400, "Invalid user_id UUID")

    memories = await memory_svc.get_user_memories(db, uid, include_archived=include_archived)
    ranked = ranking_svc.rank_memories(memories)
    return MemoryListResponse(total=len(ranked), items=ranked)


@router.patch("/{memory_id}", response_model=MemoryRead)
async def update_memory(
    memory_id: uuid.UUID,
    body: MemoryUpdate,
    user_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    try:
        uid = uuid.UUID(user_id)
    except ValueError:
        raise AppException(400, "Invalid user_id UUID")

    mem = await memory_svc.get_memory_by_id(db, memory_id, uid)
    if not mem:
        raise AppException(404, "Memory not found")

    updated = await memory_svc.update_memory_content(db, mem, body.content)
    return updated


@router.delete("/{memory_id}", status_code=204)
async def delete_memory(
    memory_id: uuid.UUID,
    user_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
    tenant: str = Depends(require_api_key),
):
    try:
        uid = uuid.UUID(user_id)
    except ValueError:
        raise AppException(400, "Invalid user_id UUID")

    mem = await memory_svc.get_memory_by_id(db, memory_id, uid)
    if not mem:
        raise AppException(404, "Memory not found")

    await memory_svc.delete_memory(db, mem)
