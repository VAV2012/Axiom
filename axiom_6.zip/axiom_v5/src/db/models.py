"""
ORM Models for Axiom Remember.

Tables
------
users            — registered users
sessions         — conversation sessions
messages         — raw conversation turns
memory           — core memory units (with pgvector embedding)
memory_links     — relationships between memory units
memory_versions  — historical versions on contradiction/update
summaries        — compressed session knowledge
user_profile     — structured long-term knowledge JSONB
"""

import uuid
from datetime import datetime, timezone
from enum import Enum as PyEnum

from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.db.connection import Base
from src.config.settings import get_settings

settings = get_settings()


# ─── Enums ────────────────────────────────────────────────────────────────────

class MemoryType(str, PyEnum):
    IDENTITY   = "identity"
    GOAL       = "goal"
    FACT       = "fact"
    PREFERENCE = "preference"
    HABIT      = "habit"
    CONSTRAINT = "constraint"
    EVENT      = "event"


class MessageRole(str, PyEnum):
    USER      = "user"
    ASSISTANT = "assistant"
    SYSTEM    = "system"


# ─── Users ────────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id:         Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    external_id: Mapped[str | None] = mapped_column(String(255), unique=True, nullable=True)
    name:       Mapped[str | None] = mapped_column(String(255), nullable=True)
    email:      Mapped[str | None] = mapped_column(String(255), unique=True, nullable=True)
    created_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    sessions: Mapped[list["Session"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    memories: Mapped[list["Memory"]]  = relationship(back_populates="user", cascade="all, delete-orphan")
    profile:  Mapped["UserProfile | None"] = relationship(back_populates="user", uselist=False, cascade="all, delete-orphan")


# ─── Sessions ─────────────────────────────────────────────────────────────────

class Session(Base):
    __tablename__ = "sessions"

    id:         Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:    Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    title:      Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_closed:  Mapped[bool]       = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    closed_at:  Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user:     Mapped["User"]         = relationship(back_populates="sessions")
    messages: Mapped[list["Message"]] = relationship(back_populates="session", cascade="all, delete-orphan", order_by="Message.created_at")
    summaries: Mapped[list["Summary"]] = relationship(back_populates="session", cascade="all, delete-orphan")


# ─── Messages ─────────────────────────────────────────────────────────────────

class Message(Base):
    __tablename__ = "messages"

    id:         Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:    Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    session_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="CASCADE"))
    role:       Mapped[str]       = mapped_column(String(20))   # MessageRole values
    content:    Mapped[str]       = mapped_column(Text)
    processed:  Mapped[bool]      = mapped_column(Boolean, default=False)
    token_count: Mapped[int]      = mapped_column(Integer, default=0)
    created_at: Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    session:  Mapped["Session"]         = relationship(back_populates="messages")
    memories: Mapped[list["Memory"]]    = relationship(back_populates="source_message")


# ─── Memory ───────────────────────────────────────────────────────────────────

class Memory(Base):
    __tablename__ = "memory"

    id:                Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:           Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    source_message_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("messages.id", ondelete="SET NULL"), nullable=True)

    # Core content
    type:       Mapped[str]   = mapped_column(String(50))   # MemoryType values
    content:    Mapped[str]   = mapped_column(Text)
    embedding:  Mapped[list | None] = mapped_column(Vector(settings.embedding_dimensions), nullable=True)

    # Scoring components
    importance:    Mapped[float] = mapped_column(Float, default=0.5)
    frequency:     Mapped[int]   = mapped_column(Integer, default=1)
    reinforcement: Mapped[float] = mapped_column(Float, default=0.0)
    score:         Mapped[float] = mapped_column(Float, default=0.0)

    # Decay / lifecycle
    decay_rate:     Mapped[float] = mapped_column(Float, default=1.0)  # multiplier on λ
    is_archived:    Mapped[bool]  = mapped_column(Boolean, default=False)
    version:        Mapped[int]   = mapped_column(Integer, default=1)

    # Timestamps
    created_at:      Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    last_accessed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at:      Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    user:           Mapped["User"]           = relationship(back_populates="memories")
    source_message: Mapped["Message | None"] = relationship(back_populates="memories")
    versions:       Mapped[list["MemoryVersion"]] = relationship(back_populates="memory", cascade="all, delete-orphan")

    # Links (self-referential via association table)
    links_from: Mapped[list["MemoryLink"]] = relationship(foreign_keys="MemoryLink.source_id", back_populates="source", cascade="all, delete-orphan")
    links_to:   Mapped[list["MemoryLink"]] = relationship(foreign_keys="MemoryLink.target_id", back_populates="target", cascade="all, delete-orphan")


# ─── Memory Versions ─────────────────────────────────────────────────────────

class MemoryVersion(Base):
    """Snapshot of a Memory before a contradiction update."""
    __tablename__ = "memory_versions"

    id:         Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    memory_id:  Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("memory.id", ondelete="CASCADE"))
    version:    Mapped[int]       = mapped_column(Integer)
    content:    Mapped[str]       = mapped_column(Text)
    type:       Mapped[str]       = mapped_column(String(50))
    score:      Mapped[float]     = mapped_column(Float)
    reason:     Mapped[str | None] = mapped_column(String(255), nullable=True)  # e.g. "contradiction"
    archived_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    memory: Mapped["Memory"] = relationship(back_populates="versions")


# ─── Memory Links ─────────────────────────────────────────────────────────────

class MemoryLink(Base):
    """Directed relationship between two memory units."""
    __tablename__ = "memory_links"
    __table_args__ = (UniqueConstraint("source_id", "target_id", "relation_type"),)

    id:            Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_id:     Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("memory.id", ondelete="CASCADE"))
    target_id:     Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("memory.id", ondelete="CASCADE"))
    relation_type: Mapped[str]       = mapped_column(String(50))  # "contradicts", "supports", "refines"
    strength:      Mapped[float]     = mapped_column(Float, default=1.0)
    created_at:    Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    source: Mapped["Memory"] = relationship(foreign_keys=[source_id], back_populates="links_from")
    target: Mapped["Memory"] = relationship(foreign_keys=[target_id], back_populates="links_to")


# ─── Summaries ────────────────────────────────────────────────────────────────

class Summary(Base):
    """Compressed representation of a session's conversation."""
    __tablename__ = "summaries"

    id:          Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:     Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    session_id:  Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="CASCADE"))
    content:     Mapped[str]       = mapped_column(Text)
    message_count: Mapped[int]     = mapped_column(Integer, default=0)
    created_at:  Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    session: Mapped["Session"] = relationship(back_populates="summaries")


# ─── User Profile ─────────────────────────────────────────────────────────────

class UserProfile(Base):
    """
    Aggregated, structured representation of the user.
    Stored as JSONB to allow flexible schema evolution.

    Structure:
    {
      "identity":    { "name": "...", "location": "...", "age": ... },
      "preferences": { "food": ["pizza", ...], "dislikes": [...] },
      "goals":       [{ "content": "...", "since": "..." }],
      "habits":      [...],
      "constraints": [...],
    }
    """
    __tablename__ = "user_profile"

    id:         Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:    Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    data:       Mapped[dict]      = mapped_column(JSONB, default=dict)
    updated_at: Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    user: Mapped["User"] = relationship(back_populates="profile")


# ─── API Keys ─────────────────────────────────────────────────────────────────

class ApiKey(Base):
    """Tenant API key — only SHA-256 hash is stored, never the raw key."""
    __tablename__ = "api_keys"

    id:           Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    key_hash:     Mapped[str]       = mapped_column(String(64), unique=True)  # SHA-256 hex of raw key
    name:         Mapped[str]       = mapped_column(String(255))
    tenant_id:    Mapped[str]       = mapped_column(String(255))
    is_active:    Mapped[bool]      = mapped_column(Boolean, default=True)
    created_at:   Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
