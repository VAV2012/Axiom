-- ============================================================
-- Axiom Remember — PostgreSQL + pgvector schema
-- Run after: CREATE EXTENSION IF NOT EXISTS vector;
-- ============================================================

-- ── Users ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_id VARCHAR(255) UNIQUE,
    name        VARCHAR(255),
    email       VARCHAR(255) UNIQUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Sessions ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title      VARCHAR(255),
    is_closed  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- ── Messages ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_id  UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    role        VARCHAR(20) NOT NULL,          -- user | assistant | system
    content     TEXT NOT NULL,
    processed   BOOLEAN NOT NULL DEFAULT FALSE,
    token_count INTEGER NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_user    ON messages(user_id);

-- ── Memory ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS memory (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    source_message_id  UUID REFERENCES messages(id) ON DELETE SET NULL,

    -- Content
    type               VARCHAR(50)  NOT NULL,   -- identity | goal | fact | preference | habit | constraint | event
    content            TEXT         NOT NULL,
    embedding          VECTOR(1536),            -- text-embedding-3-small

    -- Scoring components
    importance         FLOAT NOT NULL DEFAULT 0.5,
    frequency          INT   NOT NULL DEFAULT 1,
    reinforcement      FLOAT NOT NULL DEFAULT 0.0,
    score              FLOAT NOT NULL DEFAULT 0.0,

    -- Decay / lifecycle
    decay_rate         FLOAT   NOT NULL DEFAULT 1.0,  -- multiplier on global λ
    is_archived        BOOLEAN NOT NULL DEFAULT FALSE,
    version            INT     NOT NULL DEFAULT 1,

    -- Timestamps
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_accessed_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_memory_user       ON memory(user_id, is_archived);
CREATE INDEX IF NOT EXISTS idx_memory_score      ON memory(user_id, score DESC) WHERE is_archived = FALSE;
CREATE INDEX IF NOT EXISTS idx_memory_type       ON memory(user_id, type) WHERE is_archived = FALSE;
-- IVFFlat index for approximate nearest-neighbour search
CREATE INDEX IF NOT EXISTS idx_memory_embedding  ON memory USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- ── Memory Versions ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS memory_versions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    memory_id   UUID NOT NULL REFERENCES memory(id) ON DELETE CASCADE,
    version     INT  NOT NULL,
    content     TEXT NOT NULL,
    type        VARCHAR(50) NOT NULL,
    score       FLOAT NOT NULL,
    reason      VARCHAR(255),
    archived_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_memver_memory ON memory_versions(memory_id);

-- ── Memory Links ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS memory_links (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id     UUID NOT NULL REFERENCES memory(id) ON DELETE CASCADE,
    target_id     UUID NOT NULL REFERENCES memory(id) ON DELETE CASCADE,
    relation_type VARCHAR(50) NOT NULL,  -- contradicts | supports | refines
    strength      FLOAT NOT NULL DEFAULT 1.0,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (source_id, target_id, relation_type)
);

-- ── Summaries ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS summaries (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_id    UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    content       TEXT NOT NULL,
    message_count INT  NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_summaries_user    ON summaries(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_summaries_session ON summaries(session_id);

-- ── User Profile ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_profile (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    data       JSONB NOT NULL DEFAULT '{}',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Auto-update updated_at on memory rows
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER memory_updated_at
BEFORE UPDATE ON memory
FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER user_profile_updated_at
BEFORE UPDATE ON user_profile
FOR EACH ROW EXECUTE FUNCTION update_updated_at();
