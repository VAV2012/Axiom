-- migration_v3.sql
-- Run after migration_v2.sql
-- Adds API key authentication table for multi-tenancy support.

CREATE TABLE IF NOT EXISTS api_keys (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key_hash    VARCHAR(64) UNIQUE NOT NULL,   -- SHA-256 hex of the raw key
    name        VARCHAR(255) NOT NULL,         -- human label e.g. "Agency X production"
    tenant_id   VARCHAR(255) NOT NULL,         -- logical tenant identifier
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_used_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash) WHERE is_active = TRUE;
