"""
Pydantic v2 schemas for API I/O.
All DB UUIDs are serialised as strings for JSON compatibility.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


# ── Shared ────────────────────────────────────────────────────────────────────

class OrmBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ── Users ─────────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    name: str | None = None
    email: str | None = None
    external_id: str | None = None


class UserRead(OrmBase):
    id: uuid.UUID
    name: str | None
    email: str | None
    external_id: str | None
    created_at: datetime


# ── Sessions ──────────────────────────────────────────────────────────────────

class SessionCreate(BaseModel):
    user_id: uuid.UUID
    title: str | None = None


class SessionRead(OrmBase):
    id: uuid.UUID
    user_id: uuid.UUID
    title: str | None
    is_closed: bool
    created_at: datetime


# ── Messages ──────────────────────────────────────────────────────────────────

class MessageCreate(BaseModel):
    user_id: uuid.UUID
    session_id: uuid.UUID
    content: str = Field(..., min_length=1, max_length=32_000)
    role: str = "user"


class MessageRead(OrmBase):
    id: uuid.UUID
    user_id: uuid.UUID
    session_id: uuid.UUID
    role: str
    content: str
    processed: bool
    created_at: datetime


# ── Memory ────────────────────────────────────────────────────────────────────

class MemoryRead(OrmBase):
    id: uuid.UUID
    user_id: uuid.UUID
    type: str
    content: str
    importance: float
    frequency: int
    reinforcement: float
    score: float
    decay_rate: float
    is_archived: bool
    version: int
    created_at: datetime
    last_accessed_at: datetime


class MemoryUpdate(BaseModel):
    content: str = Field(..., min_length=1, max_length=4_000)


class MemoryListResponse(BaseModel):
    total: int
    items: list[MemoryRead]


# ── Context ───────────────────────────────────────────────────────────────────

class ContextResponse(BaseModel):
    user_id: uuid.UUID
    session_id: uuid.UUID
    recent_messages: list[dict[str, Any]]
    top_memories: list[MemoryRead]
    summaries: list[str]
    profile: dict[str, Any]


# ── Profile ───────────────────────────────────────────────────────────────────

class ProfileResponse(BaseModel):
    user_id: uuid.UUID
    identity: dict[str, Any]
    preferences: dict[str, Any]
    goals: list[dict[str, Any]]
    habits: list[str]
    constraints: list[str]
    updated_at: datetime | None = None


# ── Process message response ──────────────────────────────────────────────────

class ProcessMessageResponse(BaseModel):
    message: MessageRead
    memories_created: int
    memories_updated: int


# ── Chat ──────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    user_id: uuid.UUID
    session_id: uuid.UUID
    message: str = Field(..., min_length=1, max_length=32_000)
    system_prompt: str | None = None   # optional caller-provided system prompt override


class MemoryUsed(BaseModel):
    id: uuid.UUID
    type: str
    content: str
    score: float


class ChatResponse(BaseModel):
    reply: str
    model_used: str
    complexity: str
    memories_used: list[MemoryUsed]
    graph_additions: int
    contradictions_detected: int
    memories_created: int
    memories_updated: int
    session_id: uuid.UUID


# ── Admin ─────────────────────────────────────────────────────────────────────

class ApiKeyCreate(BaseModel):
    name: str
    tenant_id: str


class ApiKeyCreated(BaseModel):
    key: str          # shown ONCE — raw key, never stored
    id: uuid.UUID
    name: str
    tenant_id: str
    created_at: datetime


class ApiKeyRead(BaseModel):
    id: uuid.UUID
    name: str
    tenant_id: str
    is_active: bool
    created_at: datetime
    last_used_at: datetime | None
