-- ============================================================
-- Axiom Remember — Intelligence Upgrade Migration (v1 → v2)
-- Run AFTER the base schema.sql is applied.
-- ============================================================

-- 1. confidence column on memory
--    Stores the extraction confidence [0,1] from extraction.service.
--    Default 1.0 keeps existing rows scoring identically to before.
ALTER TABLE memory
  ADD COLUMN IF NOT EXISTS confidence FLOAT NOT NULL DEFAULT 1.0;

-- 2. ignore_count column on memory
--    Tracks how many times a memory was a context candidate but NOT selected.
--    Used by the ignore penalty in ranking.service / scoring.py.
--    Default 0 — existing memories have no ignore history.
ALTER TABLE memory
  ADD COLUMN IF NOT EXISTS ignore_count INTEGER NOT NULL DEFAULT 0;

-- 3. Index to help queries filtering by confidence (e.g., cleanup jobs)
CREATE INDEX IF NOT EXISTS idx_memory_confidence
  ON memory(user_id, confidence) WHERE is_archived = FALSE;

-- 4. Extend memory_links relation_type to support new strategy values
--    (schema already uses VARCHAR(50) — no change needed; just documenting)
--    Valid values now: contradicts | supports | refines | superseded_by

-- 5. (Optional) Backfill low-confidence placeholder
--    If you have existing memories with no real confidence signal,
--    you may want to set them to 0.75 (reasonable prior) rather than 1.0:
--    UPDATE memory SET confidence = 0.75 WHERE confidence = 1.0;
--    Commented out — only run if you want to retroactively penalise old memories.

COMMENT ON COLUMN memory.confidence IS
  'Extraction confidence [0,1] from extraction.service. Modulates effective importance in scoring.';

COMMENT ON COLUMN memory.ignore_count IS
  'Times this memory was evaluated for context selection but not chosen. Feeds ignore penalty in scoring.';
