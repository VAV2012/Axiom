import sys
from loguru import logger
from src.config.settings import get_settings

settings = get_settings()


def setup_logger() -> None:
    logger.remove()
    logger.add(sys.stdout, level="DEBUG" if settings.debug else "INFO", colorize=True)
    logger.add(
        "logs/axiom.log",
        level="INFO",
        rotation="10 MB",
        retention="14 days",
        compression="gz",
        serialize=True,   # structured JSON logs
    )
