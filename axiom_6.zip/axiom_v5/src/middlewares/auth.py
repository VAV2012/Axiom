"""
middlewares/auth.py — API key authentication dependency.

Usage on any route:
    tenant: str = Depends(require_api_key)

Key format: "axm_" prefix + 40 random hex chars. Example: axm_a3f9...
Storage: only SHA-256(key) is stored — raw key is shown once on creation.
"""
import hashlib

from fastapi import Header, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timezone

from src.db.connection import get_db
from src.db.models import ApiKey
from src.middlewares.error_handler import AppException


async def require_api_key(
    x_api_key: str = Header(..., alias="x-api-key"),
    db: AsyncSession = Depends(get_db),
) -> str:
    """
    Validates x-api-key header. Returns tenant_id on success.
    Raises AppException(401) if invalid or inactive.
    Updates last_used_at on every successful auth.
    """
    key_hash = hashlib.sha256(x_api_key.encode()).hexdigest()

    stmt = select(ApiKey).where(
        ApiKey.key_hash == key_hash,
        ApiKey.is_active == True,
    )
    result = await db.execute(stmt)
    api_key = result.scalar_one_or_none()

    if not api_key:
        raise AppException(401, "Invalid or inactive API key")

    # Update last_used_at
    api_key.last_used_at = datetime.now(timezone.utc)
    await db.flush()

    return api_key.tenant_id
