"""
utils/scoring.py — Upgraded pure scoring math.
Imported by ranking.service and decay.service.

Upgrade Summary vs v1
---------------------
- Type-aware weight profiles (identity ≠ event ≠ preference)
- Confidence-weighted importance (noisy extractions score lower)
- Log-scale frequency (diminishing returns, not hard cap at 10)
- Recency uses max(created_at, last_accessed_at) — actual last confirmation
- Usage score penalises memories repeatedly ignored (new: ignore_count field)
- Identity floor: identity memories score no lower than 0.25 (never auto-archived)

Formula per type:
  score = W_importance · (importance × confidence)
        + W_recency    · e^(-λ × decay_rate × days_since_confirmed)
        + W_frequency  · log(1 + frequency) / log(11)    [capped at 1.0]
        + W_usage      · max(reinforcement − 0.05×ignore_count, 0.0)
"""

import math
from datetime import datetime, timezone

from src.config.settings import get_settings

settings = get_settings()

# ── Per-type decay multipliers ──────────────────────────────────────────────
DECAY_RATE_BY_TYPE: dict[str, float] = {
    "identity":   0.20,   # near-permanent
    "goal":       0.40,   # medium — goals evolve over months
    "constraint": 0.40,   # medium — allergies/limits are durable
    "habit":      0.70,   # moderate
    "preference": 0.80,   # moderate
    "fact":       1.00,   # standard
    "event":      1.80,   # fast — past events lose relevance quickly
}

# ── Per-type scoring weight profiles ────────────────────────────────────────
# Each row: (importance, recency, frequency, usage) — sums to 1.0
WEIGHT_PROFILES: dict[str, tuple[float, float, float, float]] = {
    "identity":   (0.50, 0.20, 0.20, 0.10),
    "goal":       (0.40, 0.25, 0.20, 0.15),
    "constraint": (0.45, 0.25, 0.20, 0.10),
    "habit":      (0.35, 0.25, 0.25, 0.15),
    "preference": (0.30, 0.25, 0.25, 0.20),
    "fact":       (0.35, 0.30, 0.20, 0.15),
    "event":      (0.25, 0.40, 0.20, 0.15),
}
_DEFAULT_WEIGHTS = (0.35, 0.30, 0.20, 0.15)

IDENTITY_SCORE_FLOOR = 0.25  # identity memories are never auto-archived


def _ensure_tz(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def compute_recency_factor(
    created_at: datetime,
    last_accessed_at: datetime,
    decay_rate: float = 1.0,
) -> float:
    """
    Exponential decay anchored to max(created_at, last_accessed_at).
    Accessing a memory resets the recency clock correctly.
    f(t) = e^(-λ × decay_rate × days)
    """
    now = datetime.now(timezone.utc)
    anchor = max(_ensure_tz(created_at), _ensure_tz(last_accessed_at))
    days = max((now - anchor).total_seconds() / 86_400, 0.0)
    return math.exp(-settings.memory_decay_lambda * decay_rate * days)


def compute_log_frequency(frequency: int) -> float:
    """
    Log-scale frequency → [0, 1].
    f=1→0.29, f=3→0.54, f=5→0.71, f=10→1.0 (capped).
    More realistic than a hard cap at 10.
    """
    return min(math.log(1 + frequency) / math.log(11), 1.0)


def compute_usage_score(reinforcement: float, ignore_count: int = 0) -> float:
    """
    Net usage = reinforcement - ignore penalty.
    ignore_count: times memory was in candidate set but NOT selected for context.
    Penalty: 0.05 per ignore, capped at 10 ignores (max −0.5).
    """
    penalty = 0.05 * min(ignore_count, 10)
    return max(min(reinforcement, 1.0) - penalty, 0.0)


def compute_score(
    importance: float,
    created_at: datetime,
    last_accessed_at: datetime,
    frequency: int,
    reinforcement: float,
    decay_rate: float = 1.0,
    confidence: float = 1.0,
    ignore_count: int = 0,
    memory_type: str = "fact",
) -> float:
    """
    Composite memory score in [0.0, 1.0] with type-aware weights.

    New parameters vs v1:
      confidence   — extraction confidence [0,1]; modulates importance
      ignore_count — times this memory was skipped in context selection
      memory_type  — drives weight profile and floor logic
    """
    w_imp, w_rec, w_freq, w_usage = WEIGHT_PROFILES.get(memory_type, _DEFAULT_WEIGHTS)

    effective_importance = importance * min(max(confidence, 0.0), 1.0)
    recency = compute_recency_factor(created_at, last_accessed_at, decay_rate)
    freq    = compute_log_frequency(frequency)
    usage   = compute_usage_score(reinforcement, ignore_count)

    raw = (
        w_imp   * effective_importance
        + w_rec   * recency
        + w_freq  * freq
        + w_usage * usage
    )

    result = round(min(max(raw, 0.0), 1.0), 4)

    if memory_type == "identity":
        result = max(result, IDENTITY_SCORE_FLOOR)

    return result


def is_below_decay_threshold(score: float, memory_type: str = "fact") -> bool:
    if memory_type == "identity":
        return False  # identity is protected; use explicit archival only
    return score < settings.memory_decay_threshold


def get_importance_weight(memory_type: str) -> float:
    return settings.importance_weights.get(memory_type, 0.5)


def get_decay_rate(memory_type: str) -> float:
    return DECAY_RATE_BY_TYPE.get(memory_type, 1.0)
