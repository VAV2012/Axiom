"""
profile.service — Upgraded UserProfile aggregation.

Upgrade vs v1
-------------
1. Identity field extraction uses score-based selection (not just keyword order)
2. Preferences use confidence-weighted sorting (high-confidence prefs first)
3. Goals include a staleness indicator (score + age in days)
4. Profile sync skips re-build if no memories changed since last sync
   (tracked via a simple memory count + max updated_at check)
5. Dislike detection uses expanded negation patterns (not just 2 keywords)
"""

import re
import uuid
from datetime import datetime, timezone

from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from src.db.models import Memory, UserProfile


# Extended identity keyword map — covers more natural phrasings
_IDENTITY_KEYS = {
    "name":     ["name is", "called", "my name", "i am", "i'm"],
    "location": ["live in", "based in", "located in", "moved to", "from", "living in", "reside in"],
    "job":      ["work at", "working at", "job at", "employed at", "position at",
                 "i am a", "i'm a", "work as", "working as", "my job is", "i do"],
    "age":      ["years old", "aged", "born in", "i am", "i'm"],
}

# Expanded dislike / negation patterns
_DISLIKE_PATTERNS = [
    r"\bdislik", r"\bdon'?t like", r"\bdoes not like", r"\bcan'?t stand",
    r"\bhate", r"\bavoide?", r"\bnot a fan", r"\bnot into", r"\bnot fond",
]
_DISLIKE_RE = [re.compile(p, re.IGNORECASE) for p in _DISLIKE_PATTERNS]


def _is_dislike(content: str) -> bool:
    return any(r.search(content) for r in _DISLIKE_RE)


def _extract_identity_fields(memories: list[Memory]) -> dict:
    """
    Upgrade: pick the highest-scored (most confident/relevant) memory per field.
    v1 picked the first keyword match regardless of quality.
    """
    identity: dict = {}
    identity_mems = sorted(
        [m for m in memories if m.type == "identity"],
        key=lambda m: m.score,
        reverse=True,
    )

    for mem in identity_mems:
        content_lower = mem.content.lower()
        for field, keywords in _IDENTITY_KEYS.items():
            if field not in identity and any(k in content_lower for k in keywords):
                identity[field] = mem.content
    return identity


def _memory_age_days(mem: Memory) -> int:
    now = datetime.now(timezone.utc)
    created = mem.created_at if mem.created_at.tzinfo else mem.created_at.replace(tzinfo=timezone.utc)
    return int((now - created).total_seconds() / 86_400)


async def sync_profile(db: AsyncSession, user_id: uuid.UUID) -> UserProfile:
    """
    Rebuild the UserProfile from active memories and persist it.
    Idempotent — safe to call multiple times.

    Upgrade: dirty-check before full rebuild. If memory count and latest
    updated_at haven't changed since last profile sync, skip the O(n) scan.
    """
    from sqlalchemy import func as sqlfunc

    # Fast check: count + max(updated_at) of active memories
    check_stmt = select(
        sqlfunc.count(Memory.id),
        sqlfunc.max(Memory.updated_at),
    ).where(and_(Memory.user_id == user_id, Memory.is_archived == False))
    check_result = await db.execute(check_stmt)
    mem_count, max_updated = check_result.one()

    # Load existing profile to compare
    profile_stmt = select(UserProfile).where(UserProfile.user_id == user_id)
    profile_result = await db.execute(profile_stmt)
    profile = profile_result.scalar_one_or_none()

    if profile and profile.data:
        cached_meta = profile.data.get("_meta", {})
        if (
            cached_meta.get("mem_count") == mem_count
            and cached_meta.get("max_updated") == (max_updated.isoformat() if max_updated else None)
        ):
            logger.debug(f"[Profile] Skipped rebuild — no changes (user {user_id!s:.8})")
            return profile

    # Full rebuild needed
    stmt = select(Memory).where(
        and_(Memory.user_id == user_id, Memory.is_archived == False)
    )
    result = await db.execute(stmt)
    memories: list[Memory] = list(result.scalars().all())

    identity = _extract_identity_fields(memories)

    # Preferences — split by dislike patterns, sorted by score (high confidence first)
    pref_mems = sorted([m for m in memories if m.type == "preference"], key=lambda m: m.score, reverse=True)
    preferences = {
        "likes":    [m.content for m in pref_mems if not _is_dislike(m.content)],
        "dislikes": [m.content for m in pref_mems if _is_dislike(m.content)],
    }

    # Goals — include score and age for staleness awareness
    goal_mems = sorted([m for m in memories if m.type == "goal"], key=lambda m: m.score, reverse=True)
    goals = [
        {
            "content":   m.content,
            "since":     m.created_at.isoformat(),
            "score":     round(m.score, 3),
            "age_days":  _memory_age_days(m),
        }
        for m in goal_mems
    ]

    # Habits — sorted by score
    habits = [
        m.content for m in sorted(
            [m for m in memories if m.type == "habit"],
            key=lambda m: m.score, reverse=True
        )
    ]

    # Constraints — sorted by score (most reliable first)
    constraints = [
        m.content for m in sorted(
            [m for m in memories if m.type == "constraint"],
            key=lambda m: m.score, reverse=True
        )
    ]

    data = {
        "_meta": {
            "mem_count":   mem_count,
            "max_updated": max_updated.isoformat() if max_updated else None,
        },
        "identity":    identity,
        "preferences": preferences,
        "goals":       goals,
        "habits":      habits,
        "constraints": constraints,
    }

    # Upsert
    if profile:
        profile.data       = data
        profile.updated_at = datetime.now(timezone.utc)
    else:
        profile = UserProfile(user_id=user_id, data=data)
        db.add(profile)

    await db.flush()
    logger.debug(f"[Profile] Synced for user {user_id!s:.8} | {len(memories)} memories")
    return profile


async def get_profile(db: AsyncSession, user_id: uuid.UUID) -> UserProfile | None:
    stmt = select(UserProfile).where(UserProfile.user_id == user_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()
