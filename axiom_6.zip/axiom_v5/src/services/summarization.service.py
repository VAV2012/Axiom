"""
summarization.service — LLM-powered session compression.

When a session accumulates enough messages (settings.summarize_min_messages),
this service compresses the conversation into a concise Summary row and
removes the now-redundant old messages to keep the DB lean.

Called by: jobs/summarization_job.py
"""

import uuid

from openai import AsyncOpenAI
from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from src.db.models import Message, Session, Summary
from src.config.settings import get_settings

settings = get_settings()

SUMMARIZE_PROMPT = """You are a memory summariser for an AI assistant.

Given a conversation excerpt, produce a concise factual summary (max 200 words) that captures:
- What was discussed
- Any decisions or conclusions reached
- Key facts mentioned

Be objective and factual. Write in third-person. Do not include filler or pleasantries.
"""


async def summarize_session(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
) -> Summary | None:
    """
    Summarise messages in a session if the count exceeds the threshold.
    Returns the Summary if created, else None.
    """
    # Count processed messages
    count_stmt = select(func.count()).where(
        and_(
            Message.session_id == session_id,
            Message.processed == True,
        )
    )
    count_result = await db.execute(count_stmt)
    msg_count = count_result.scalar() or 0

    if msg_count < settings.summarize_min_messages:
        return None

    # Check if we already summarised this session recently
    existing_stmt = (
        select(Summary)
        .where(Summary.session_id == session_id)
        .order_by(Summary.created_at.desc())
        .limit(1)
    )
    existing_result = await db.execute(existing_stmt)
    latest_summary = existing_result.scalar_one_or_none()

    # Only summarise messages that are newer than the last summary
    msg_stmt = select(Message).where(
        and_(
            Message.session_id == session_id,
            Message.created_at > latest_summary.created_at if latest_summary else True,
        )
    ).order_by(Message.created_at.asc())

    msg_result = await db.execute(msg_stmt)
    messages = list(msg_result.scalars().all())

    if len(messages) < settings.summarize_min_messages:
        return None

    transcript = "\n".join(f"{m.role.upper()}: {m.content}" for m in messages)
    summary_text = await _call_llm(transcript)

    if not summary_text:
        return None

    summary = Summary(
        user_id=user_id,
        session_id=session_id,
        content=summary_text,
        message_count=len(messages),
    )
    db.add(summary)
    await db.flush()

    logger.info(
        f"[Summarization] Session {session_id}: compressed {len(messages)} messages"
    )
    return summary


async def _call_llm(transcript: str) -> str | None:
    try:
        client = AsyncOpenAI(api_key=settings.openai_api_key)
        resp = await client.chat.completions.create(
            model=settings.summarization_model,
            messages=[
                {"role": "system", "content": SUMMARIZE_PROMPT},
                {"role": "user",   "content": transcript[:12_000]},  # token guard
            ],
            temperature=0.2,
            max_tokens=400,
        )
        return resp.choices[0].message.content.strip()
    except Exception as exc:
        logger.error(f"[Summarization] LLM call failed: {exc}")
        return None
