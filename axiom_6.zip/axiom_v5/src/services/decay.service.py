"""
decay.service — Upgraded memory decay with type-aware protection.

Upgrade vs v1
-------------
1. Identity memories are never archived by decay (protected type)
2. Low-confidence memories decay faster (confidence field integration)
3. Decay run checks time since last run to avoid redundant DB writes
   (v1 ran every hour but scored at day granularity — 24× wasted compute)
4. Passes memory_type to is_below_decay_threshold for identity protection
5. Logs decay by type for observability

Called by: jobs/decay_job.py
"""

from datetime import datetime, timezone, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from src.db.models import Memory
from src.services import ranking as ranking_svc
from src.utils.scoring import is_below_decay_threshold

# Minimum real-world time between decay runs that actually writes to DB.
# Scoring is day-granularity — running every hour is 24× wasted compute.
_DECAY_MIN_INTERVAL_HOURS = 6
_last_decay_run: datetime | None = None


async def run_decay(db: AsyncSession) -> dict:
    """
    Rescore all active memories; archive those below the decay threshold.

    Time-gate: if decay ran less than _DECAY_MIN_INTERVAL_HOURS ago,
    skip the DB write and return early. Scores don't change meaningfully
    at sub-day granularity.
    """
    global _last_decay_run
    now = datetime.now(timezone.utc)

    if _last_decay_run is not None:
        elapsed_hours = (now - _last_decay_run).total_seconds() / 3600
        if elapsed_hours < _DECAY_MIN_INTERVAL_HOURS:
            logger.debug(
                f"[Decay] Skipped — last run {elapsed_hours:.1f}h ago "
                f"(min interval {_DECAY_MIN_INTERVAL_HOURS}h)"
            )
            return {"skipped": True, "hours_since_last": round(elapsed_hours, 1)}
    stmt = select(Memory).where(Memory.is_archived == False)
    result = await db.execute(stmt)
    memories: list[Memory] = list(result.scalars().all())

    rescored = 0
    archived = 0
    protected = 0
    stats_by_type: dict[str, int] = {}

    for mem in memories:
        old_score = mem.score
        mem.score = ranking_svc.score_memory(mem)
        rescored += 1

        # Type-aware threshold check — identity memories are never auto-archived
        if is_below_decay_threshold(mem.score, memory_type=mem.type):
            mem.is_archived = True
            archived += 1
            stats_by_type[mem.type] = stats_by_type.get(mem.type, 0) + 1
            logger.info(
                f"[Decay] Archived {mem.type} memory {mem.id!s:.8} "
                f"(score {old_score:.4f} → {mem.score:.4f})"
            )
        elif mem.type == "identity" and mem.score < 0.30:
            # Log but do NOT archive — identity is protected
            protected += 1
            logger.debug(
                f"[Decay] Identity memory {mem.id!s:.8} score={mem.score:.4f} "
                f"(low but protected)"
            )

    await db.flush()

    _last_decay_run = datetime.now(timezone.utc)

    logger.info(
        f"[Decay] Rescored {rescored} | Archived {archived} | Protected {protected} "
        f"| By type: {stats_by_type}"
    )
    return {
        "rescored": rescored,
        "archived": archived,
        "protected": protected,
        "archived_by_type": stats_by_type,
    }
