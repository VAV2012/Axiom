"""
model_router.py — Classifies task complexity and selects the appropriate model.

Complexity tiers:
  SIMPLE    → simple_model (fast, cheap — factual Q&A, greetings, lookups)
  MODERATE  → simple_model (default — most tasks)
  COMPLEX   → complex_model (slow, expensive — reasoning, contradiction, planning)

Classification is heuristic-first (instant, zero API cost).
Falls back to LLM classification only for ambiguous cases.
"""
from typing import Literal

from src.config.settings import get_settings
from src.services import llm_client

settings = get_settings()

Complexity = Literal["SIMPLE", "MODERATE", "COMPLEX"]

# Model assignments per tier — driven by settings so they can be overridden via env
def _model_map() -> dict[str, str]:
    return {
        "SIMPLE":   settings.simple_model,
        "MODERATE": settings.simple_model,
        "COMPLEX":  settings.complex_model,
    }


# Keywords that push toward COMPLEX
_COMPLEX_KEYWORDS = [
    "plan", "strategy", "compare", "analyze", "analyse",
    "explain why", "step by step", "help me decide",
    "pros and cons", "difference between",
]

# Keywords that indicate SIMPLE (greeting-like)
_SIMPLE_KEYWORDS = ["hi", "hello", "thanks", "ok", "yes", "no", "bye"]


def _classify_heuristic(message: str, ctx: dict) -> Complexity | None:
    """
    Fast heuristic classifier. Returns a Complexity or None (ambiguous).
    ctx: the dict returned by context_svc.build_context()
    """
    msg_lower = message.lower().strip()
    msg_len = len(message)
    top_memories = ctx.get("top_memories", [])

    # Check for contradiction links among selected memories
    has_contradiction = False
    # Memory objects may have links_from loaded; check via contradictions key if present
    contradictions = ctx.get("contradictions", [])
    if contradictions:
        has_contradiction = True

    # ── COMPLEX signals ────────────────────────────────────────────────────
    if msg_len > 600:
        return "COMPLEX"
    if any(kw in msg_lower for kw in _COMPLEX_KEYWORDS):
        return "COMPLEX"
    if len(top_memories) > 6:
        return "COMPLEX"
    if has_contradiction:
        return "COMPLEX"

    # ── SIMPLE signals ─────────────────────────────────────────────────────
    question_marks = message.count("?")
    is_short = msg_len < 120
    is_simple_keyword = any(kw in msg_lower for kw in _SIMPLE_KEYWORDS)
    few_or_no_questions = question_marks <= 1

    if is_short and few_or_no_questions and not has_contradiction and is_simple_keyword:
        return "SIMPLE"

    # Ambiguous — fall through to LLM
    return None


async def _classify_llm(message: str) -> Complexity:
    """
    LLM-based classifier for ambiguous messages.
    Always uses the cheap model — never the expensive one just to classify.
    """
    system = (
        "You are a task complexity classifier. Reply with ONLY one word: SIMPLE, MODERATE, or COMPLEX.\n\n"
        "SIMPLE: Single-fact lookup, greeting, yes/no, short factual answer possible.\n"
        "MODERATE: Requires some reasoning, personalisation, or multi-step response.\n"
        "COMPLEX: Requires deep reasoning, planning, comparison, contradiction resolution, or long analysis."
    )
    reply = await llm_client.chat(
        model=settings.simple_model,
        system=system,
        user=message,
        max_tokens=10,
        temperature=0.0,
    )
    result = reply.strip().upper()
    if result not in ("SIMPLE", "MODERATE", "COMPLEX"):
        return "MODERATE"
    return result  # type: ignore[return-value]


async def select_model(message: str, ctx: dict) -> tuple[str, Complexity]:
    """
    Returns (model_name, complexity_tier).
    ctx: the dict returned by context_svc.build_context()
    """
    complexity = _classify_heuristic(message, ctx)
    if complexity is None:
        complexity = await _classify_llm(message)
    model = _model_map()[complexity]
    return model, complexity
