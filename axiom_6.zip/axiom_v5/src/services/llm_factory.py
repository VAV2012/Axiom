"""
llm_factory.py — Provider factory + singleton cache.

Feature 1 upgrade vs before
-----------------------------
Previously: each service imported AsyncOpenAI directly.
Now: all LLM calls route through get_llm_provider() / get_embedding_provider().
Switching the LLM requires only a single env-var change:
    LLM_PROVIDER=anthropic   # or gemini | ollama | openai (default)

Embedding provider always defaults to openai because pgvector requires a
fixed 1536-d space — other providers either don't offer embeddings or use
incompatible dimensions. Override with EMBEDDING_PROVIDER=openai if needed.
"""
from __future__ import annotations

from loguru import logger

from src.config.settings import get_settings
from src.services.llm_provider import (
    BaseLLMProvider,
    OpenAIProvider,
    AnthropicProvider,
    GeminiProvider,
    OllamaProvider,
)

_chat_provider_cache: BaseLLMProvider | None = None
_embedding_provider_cache: BaseLLMProvider | None = None


def get_llm_provider() -> BaseLLMProvider:
    """
    Return a singleton LLM provider for chat / extraction calls.
    Reads LLM_PROVIDER from settings on first call, then caches.
    """
    global _chat_provider_cache
    if _chat_provider_cache is not None:
        return _chat_provider_cache

    settings = get_settings()
    provider_name = settings.llm_provider.lower()
    logger.info(f"[LLMFactory] Initialising chat provider: {provider_name}")

    if provider_name == "openai":
        _chat_provider_cache = OpenAIProvider(
            api_key=settings.openai_api_key,
            embedding_model=settings.embedding_model,
            embedding_dimensions=settings.embedding_dimensions,
        )
    elif provider_name == "anthropic":
        _chat_provider_cache = AnthropicProvider(api_key=settings.anthropic_api_key)
    elif provider_name == "gemini":
        _chat_provider_cache = GeminiProvider(api_key=settings.gemini_api_key)
    elif provider_name == "ollama":
        _chat_provider_cache = OllamaProvider(
            base_url=settings.ollama_base_url,
            chat_model=settings.ollama_chat_model,
        )
    else:
        logger.warning(
            f"[LLMFactory] Unknown provider '{provider_name}', falling back to openai"
        )
        _chat_provider_cache = OpenAIProvider(
            api_key=settings.openai_api_key,
            embedding_model=settings.embedding_model,
            embedding_dimensions=settings.embedding_dimensions,
        )

    return _chat_provider_cache


def get_embedding_provider() -> BaseLLMProvider:
    """
    Return a singleton provider for embedding calls.
    Always OpenAIProvider unless EMBEDDING_PROVIDER is explicitly set
    (currently only "openai" is supported — other providers don't offer
    pgvector-compatible 1536-d embeddings).
    """
    global _embedding_provider_cache
    if _embedding_provider_cache is not None:
        return _embedding_provider_cache

    settings = get_settings()
    embed_prov = getattr(settings, "embedding_provider", "openai").lower()
    logger.info(f"[LLMFactory] Initialising embedding provider: {embed_prov}")

    # Always openai for now — the only provider with 1536-d text-embedding-3-small
    _embedding_provider_cache = OpenAIProvider(
        api_key=settings.openai_api_key,
        embedding_model=settings.embedding_model,
        embedding_dimensions=settings.embedding_dimensions,
    )
    return _embedding_provider_cache
