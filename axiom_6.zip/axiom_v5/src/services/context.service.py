"""
context.service — Upgraded context assembly for LLM system prompts.

Upgrade vs v1 (CRITICAL PATH)
------------------------------
v1 problems:
  - pgvector rank used as-is (no score combination)
  - Two disconnected ranked lists concatenated
  - No redundancy filter between selected memories
  - All surfaced memories reinforced (including score-ranked fallbacks)
  - No ignore penalty for memories that were evaluated but skipped
  - Profile always dumped in full

New strategy: Combined Relevance Score
  context_score = α · semantic_sim + β · memory.score + γ · recency_bonus
  where α=0.50, β=0.35, γ=0.15

Algorithm:
  1. Semantic search: retrieve top 30 candidates (wider net than final budget)
  2. Compute context_score for each candidate
  3. Sort all candidates by context_score descending
  4. Redundancy filter: skip if cosine_sim > 0.85 with any already-selected memory
  5. Take top K (default 8 — tighter, higher quality)
  6. Reinforce ONLY semantically retrieved memories (not score-ranked fallbacks)
  7. Apply ignore penalty to evaluated-but-rejected candidates
  8. Include relevance-filtered profile (not full dump)
"""

import math
import uuid
from datetime import datetime, timezone

from sqlalchemy import select, text, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from src.db.models import Memory, MemoryLink, Summary, UserProfile
from src.services import embedding as embedding_svc
from src.services import memory as memory_svc
from src.services import ranking as ranking_svc
from src.config.settings import get_settings

settings = get_settings()

# ── Tunable weights ─────────────────────────────────────────────────────────
ALPHA = 0.50   # semantic similarity weight
BETA  = 0.35   # memory quality score weight
GAMMA = 0.15   # recency bonus weight

# Redundancy suppression threshold
REDUNDANCY_SIM_THRESHOLD = 0.85

# Candidate pool size (wider than final budget to allow filtering)
CANDIDATE_POOL_SIZE = 30

# Final context budget — tighter than v1's 10
CONTEXT_BUDGET = getattr(settings, "context_top_memories", 10)


def _recency_bonus(memory: Memory) -> float:
    """Fast recency bonus: 1.0 if accessed today, decays to 0 over 30 days."""
    now = datetime.now(timezone.utc)
    anchor = memory.last_accessed_at
    if anchor.tzinfo is None:
        anchor = anchor.replace(tzinfo=timezone.utc)
    days = (now - anchor).total_seconds() / 86_400
    return math.exp(-days / 30.0)  # 30-day half-life for recency bonus


def _context_score(memory: Memory, semantic_sim: float) -> float:
    """
    Combined relevance score for context selection.
    semantic_sim: cosine similarity to query [0, 1]
    memory.score: pre-computed composite quality score [0, 1]
    recency:      fast recency bonus [0, 1]
    """
    return (
        ALPHA * semantic_sim
        + BETA  * memory.score
        + GAMMA * _recency_bonus(memory)
    )


def _normalize(v: list[float]) -> list[float]:
    """Return L2-normalized copy. Returns zero-vector if norm is zero."""
    norm = math.sqrt(sum(x * x for x in v))
    if norm == 0:
        return v
    return [x / norm for x in v]


def _dot(a: list[float], b: list[float]) -> float:
    """Dot product of two pre-normalized vectors == cosine similarity."""
    return sum(x * y for x, y in zip(a, b))




async def _traverse_links(
    db: AsyncSession,
    selected_memories: list[Memory],
    max_hops: int = 1,
    max_additions: int = 3,
) -> tuple[list[Memory], list[dict]]:
    """
    Given already-selected memories, follow their MemoryLinks to find
    additional relevant memories not caught by semantic search.

    Returns (additional_memories, contradiction_links).
    """
    selected_ids = {m.id for m in selected_memories}

    # Fetch additive links (supports + refines)
    stmt = select(MemoryLink).where(
        MemoryLink.source_id.in_(selected_ids),
        MemoryLink.relation_type.in_(["supports", "refines"]),
    )
    result = await db.execute(stmt)
    links = result.scalars().all()

    candidate_ids = [
        link.target_id for link in links
        if link.target_id not in selected_ids
    ]

    additions: list[Memory] = []
    if candidate_ids:
        mem_stmt = select(Memory).where(
            Memory.id.in_(candidate_ids),
            Memory.is_archived == False,
            Memory.score > settings.graph_min_score,
        )
        mem_result = await db.execute(mem_stmt)
        candidates = list(mem_result.scalars().all())
        candidates.sort(key=lambda m: m.score, reverse=True)
        additions = candidates[:max_additions]

    # Detect contradictions among selected memories
    contradiction_stmt = select(MemoryLink).where(
        MemoryLink.source_id.in_(selected_ids),
        MemoryLink.relation_type == "contradicts",
    )
    contradiction_result = await db.execute(contradiction_stmt)
    contradiction_links = contradiction_result.scalars().all()
    contradictions = [
        {"source_id": str(link.source_id), "target_id": str(link.target_id)}
        for link in contradiction_links
    ]

    return additions, contradictions

async def build_context(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
    query: str | None = None,
) -> dict:
    """
    Build the context dict for LLM injection.

    Key upgrade: when a query is present, uses unified combined-relevance
    scoring across all candidates rather than two disconnected ranked lists.
    """
    query_embedding: list[float] | None = None
    semantic_candidates: list[tuple[Memory, float]] = []  # (memory, sim)

    # 1. Semantic retrieval — wider pool than final budget
    if query:
        try:
            query_embedding = await embedding_svc.get_embedding(query)
            semantic_candidates = await _semantic_search_with_scores(
                db, user_id, query_embedding, limit=CANDIDATE_POOL_SIZE
            )
        except Exception as exc:
            logger.warning(f"[Context] Semantic search failed: {exc}")

    # 2. If no query or semantic search failed, fall back to score-ranked memories
    if not semantic_candidates:
        all_mems = await memory_svc.get_user_memories(db, user_id)
        ranked   = ranking_svc.rank_memories(all_mems, top_k=CANDIDATE_POOL_SIZE)
        # Assign sim=0 since we have no query embedding
        semantic_candidates = [(m, 0.0) for m in ranked]
        query_embedding = None  # ensure we don't use it below

    # 3. Compute combined context_score for each candidate
    scored: list[tuple[Memory, float, float]] = []  # (memory, context_score, sim)
    for mem, sim in semantic_candidates:
        cs = _context_score(mem, sim)
        scored.append((mem, cs, sim))

    # Sort by context_score descending
    scored.sort(key=lambda x: x[1], reverse=True)

    # 4. Redundancy filter — select diverse memories
    # Pre-normalize all embeddings once so the inner loop is pure dot products
    norm_cache: dict[int, list[float]] = {}
    def _get_norm(mem: Memory) -> list[float] | None:
        if mem.embedding is None:
            return None
        mid = id(mem)
        if mid not in norm_cache:
            norm_cache[mid] = _normalize(mem.embedding)
        return norm_cache[mid]

    selected: list[Memory] = []
    selected_norms: list[list[float]] = []
    rejected_semantic: list[Memory] = []   # evaluated but skipped — for ignore penalty

    for mem, cs, sim in scored:
        if len(selected) >= CONTEXT_BUDGET:
            # Still track evaluated-but-cut memories for ignore penalty
            if sim > 0:
                rejected_semantic.append(mem)
            continue

        # Skip if too similar to an already-selected memory
        mem_norm = _get_norm(mem)
        if selected_norms and mem_norm:
            max_overlap = max(_dot(mem_norm, sel_n) for sel_n in selected_norms)
            if max_overlap > REDUNDANCY_SIM_THRESHOLD:
                rejected_semantic.append(mem)
                continue

        selected.append(mem)
        if mem_norm:
            selected_norms.append(mem_norm)

    # 4b. Graph traversal — add linked memories not found by semantic search
    linked_additions, contradictions = await _traverse_links(
        db, selected,
        max_hops=settings.graph_max_hops,
        max_additions=settings.graph_max_additions,
    )
    n_graph = len(linked_additions)
    selected.extend(linked_additions)

    logger.info(
        f"[Context] user={user_id} | semantic={len(selected)-n_graph} "
        f"| graph_additions={n_graph} | contradictions={len(contradictions)}"
    )

    # 5. Reinforcement — ONLY for semantically retrieved memories
    #    (not for score-ranked fallbacks when no query was present)
    if query_embedding is not None:
        semantic_ids = {m.id for m, _ in semantic_candidates}
        to_reinforce = [m for m in selected if m.id in semantic_ids]
        await memory_svc.reinforce_memories(db, to_reinforce)

    # 6. Ignore penalty for candidates that were evaluated but excluded
    #    Cap DB writes at 15 to avoid excessive flush cost, but penalise all
    #    in-memory so scores reflect reality within this request cycle
    for mem in rejected_semantic:
        ranking_svc.apply_ignore_penalty(mem)
    if rejected_semantic:
        await db.flush()

    # 7. Recent messages (short-term window)
    recent = await memory_svc.get_recent_messages(db, user_id, session_id)
    recent_serialised = [
        {"role": m.role, "content": m.content, "ts": m.created_at.isoformat()}
        for m in recent
    ]

    # 8. Session summaries
    summaries = await _get_summaries(db, user_id, session_id)

    # 9. Profile — filtered to query relevance (not full dump)
    profile_data = await _get_filtered_profile(db, user_id, query)

    logger.info(
        f"[Context] user={user_id} | final={len(selected)} memories "
        f"| rejected={len(rejected_semantic)} | messages={len(recent)}"
    )

    return {
        "user_id":         str(user_id),
        "session_id":      str(session_id),
        "recent_messages": recent_serialised,
        "top_memories":    selected,        # ORM objects; controller serialises
        "summaries":       summaries,
        "profile":         profile_data,
        "contradictions":  contradictions,
        "graph_additions": n_graph,
    }


async def _semantic_search_with_scores(
    db: AsyncSession,
    user_id: uuid.UUID,
    query_embedding: list[float],
    limit: int = CANDIDATE_POOL_SIZE,
) -> list[tuple[Memory, float]]:
    """
    pgvector ANN search. Returns (Memory, cosine_similarity) pairs.
    Upgrade: also computes and returns the similarity score for combined ranking.
    """
    vec_literal = "[" + ",".join(str(x) for x in query_embedding) + "]"
    stmt = text(
        """
        SELECT id, 1 - (embedding <=> :embedding) AS similarity
        FROM memory
        WHERE user_id = :user_id
          AND is_archived = FALSE
          AND embedding IS NOT NULL
        ORDER BY embedding <=> :embedding
        LIMIT :limit
        """
    ).bindparams(
        user_id=str(user_id),
        embedding=vec_literal,
        limit=limit,
    )
    result = await db.execute(stmt)
    rows = result.fetchall()

    if not rows:
        return []

    id_to_sim = {row[0]: float(row[1]) for row in rows}
    ids = list(id_to_sim.keys())

    mem_stmt = select(Memory).where(Memory.id.in_(ids))
    mem_result = await db.execute(mem_stmt)
    memories = list(mem_result.scalars().all())

    # Pair each memory with its similarity, preserving pgvector order
    paired = [(m, id_to_sim.get(m.id, 0.0)) for m in memories]
    paired.sort(key=lambda x: x[1], reverse=True)
    return paired


async def _get_summaries(
    db: AsyncSession,
    user_id: uuid.UUID,
    session_id: uuid.UUID,
) -> list[str]:
    stmt = (
        select(Summary)
        .where(and_(Summary.user_id == user_id, Summary.session_id == session_id))
        .order_by(Summary.created_at.desc())
        .limit(3)
    )
    result = await db.execute(stmt)
    return [s.content for s in result.scalars().all()]


async def _get_filtered_profile(
    db: AsyncSession,
    user_id: uuid.UUID,
    query: str | None,
) -> dict:
    """
    Return profile fields relevant to the query rather than the full profile.

    Always included: identity.name, active constraints.
    Conditionally included based on query keywords:
      - food/diet/eat/drink       → constraints + food preferences
      - work/job/career/project   → identity.job + goals
      - travel/trip/location      → identity.location
      - (no query)                → full profile (backward compatible)
    """
    stmt = select(UserProfile).where(UserProfile.user_id == user_id)
    result = await db.execute(stmt)
    profile = result.scalar_one_or_none()

    if not profile or not profile.data:
        return {}

    data = profile.data

    # No query → return everything (fallback behaviour)
    if not query:
        return data

    q = query.lower()
    filtered: dict = {}

    # Always include name if present
    identity = data.get("identity", {})
    if identity.get("name"):
        filtered.setdefault("identity", {})["name"] = identity["name"]

    # Always include constraints (safety-relevant)
    if data.get("constraints"):
        filtered["constraints"] = data["constraints"]

    # Conditional inclusions
    if any(kw in q for kw in ["food", "eat", "drink", "diet", "vegan", "vegetarian", "allergy", "cook", "recipe"]):
        if data.get("preferences"):
            filtered["preferences"] = data["preferences"]

    if any(kw in q for kw in ["work", "job", "career", "project", "profession", "company"]):
        if identity.get("job"):
            filtered.setdefault("identity", {})["job"] = identity["job"]
        if data.get("goals"):
            filtered["goals"] = data["goals"]

    if any(kw in q for kw in ["travel", "trip", "location", "city", "country", "move", "live"]):
        if identity.get("location"):
            filtered.setdefault("identity", {})["location"] = identity["location"]

    if any(kw in q for kw in ["goal", "plan", "want", "achieve", "target"]):
        if data.get("goals"):
            filtered["goals"] = data["goals"]

    # If nothing matched the filters, return a safe minimal set
    if not filtered:
        minimal = {}
        if identity:
            minimal["identity"] = {k: v for k, v in identity.items() if k in ("name", "job")}
        if data.get("constraints"):
            minimal["constraints"] = data["constraints"]
        return minimal

    return filtered
