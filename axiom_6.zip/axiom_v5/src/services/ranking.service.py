"""
ranking.service — Score and rank Memory objects.

Upgrade vs v1
-------------
- Passes confidence and ignore_count to compute_score (new fields)
- apply_reinforcement now decays the boost over time (not always flat +0.1)
- apply_ignore_penalty: NEW — penalises memories skipped during context selection
- rank_memories gains a min_score filter to avoid returning garbage memories
"""

from src.db.models import Memory
from src.utils.scoring import compute_score
from src.config.settings import get_settings

settings = get_settings()


def score_memory(memory: Memory) -> float:
    """Compute composite score for a Memory ORM object."""
    return compute_score(
        importance=memory.importance,
        created_at=memory.created_at,
        last_accessed_at=memory.last_accessed_at,
        frequency=memory.frequency,
        reinforcement=memory.reinforcement,
        decay_rate=memory.decay_rate,
        confidence=getattr(memory, "confidence", 1.0),    # new field — safe default
        ignore_count=getattr(memory, "ignore_count", 0),  # new field — safe default
        memory_type=memory.type,
    )


def rank_memories(
    memories: list[Memory],
    top_k: int | None = None,
    min_score: float = 0.0,
) -> list[Memory]:
    """
    Rescore all memories, filter by min_score, return sorted list.
    min_score default=0.0 preserves backward compatibility.
    Set min_score=0.15 to match decay threshold in callers that want quality only.
    """
    for mem in memories:
        mem.score = score_memory(mem)

    ranked = [m for m in memories if m.score >= min_score]
    ranked.sort(key=lambda m: m.score, reverse=True)
    return ranked[:top_k] if top_k else ranked


def apply_reinforcement(memory: Memory, boost: float = 0.1) -> None:
    """
    Increment reinforcement when a memory is surfaced to the LLM.

    Upgrade: diminishing boost. Memories that are already highly reinforced
    receive a smaller increment. This prevents a single "popular" memory
    from hitting 1.0 and staying there permanently regardless of quality.

    New boost = base_boost × (1 - reinforcement × 0.5)
    So: reinforcement=0.0 → full boost; reinforcement=0.8 → 60% of boost.
    """
    effective_boost = boost * (1.0 - memory.reinforcement * 0.5)
    memory.reinforcement = round(min(memory.reinforcement + effective_boost, 1.0), 4)
    memory.score = score_memory(memory)


def apply_ignore_penalty(memory: Memory) -> None:
    """
    NEW: Penalise a memory that was a candidate but was not selected for context.

    Increments ignore_count. compute_score will reduce the usage component
    proportionally. This creates a negative feedback loop:
    - Semantically retrieved but always skipped → score gradually drops
    - Eventually falls below decay threshold and is archived

    Only call this for memories that were genuinely evaluated (had a chance
    to be selected) but were excluded — not for memories never retrieved.
    """
    if not hasattr(memory, "ignore_count"):
        return  # field not present in this DB version — skip safely
    memory.ignore_count = min(getattr(memory, "ignore_count", 0) + 1, 50)
    memory.score = score_memory(memory)
