"""
llm_provider.py — LLM-agnostic provider abstraction layer.

Feature 1 upgrade vs before
-----------------------------
Previously: llm_client.py and extraction.service.py were hardcoded to OpenAI.
Now: All LLM calls go through a provider interface. Concrete implementations exist
for OpenAI, Anthropic Claude, Google Gemini, and Ollama (local). Switching
providers is a single env-var change (LLM_PROVIDER=anthropic).

Providers:
  - OpenAIProvider    — AsyncOpenAI singleton (original behaviour, default)
  - AnthropicProvider — anthropic SDK, model: claude-sonnet-4-20250514
  - GeminiProvider    — google-generativeai SDK, model: gemini-2.0-flash
  - OllamaProvider    — HTTP to http://localhost:11434, model configurable

Embeddings always use OpenAI (text-embedding-3-small) unless an explicit
embedding provider is configured. OpenAI is the only provider with a
pgvector-compatible 1536-d embedding model available out of the box.
"""
from __future__ import annotations

import abc
import json
from typing import AsyncGenerator

from loguru import logger


# ─────────────────────────────────────────────────────────────────────────────
# Abstract base
# ─────────────────────────────────────────────────────────────────────────────

class BaseLLMProvider(abc.ABC):
    """
    All providers must implement these four async methods.
    embed() is optional — providers that don't support embeddings should raise
    NotImplementedError; the factory will fall back to OpenAIProvider for embeds.
    """

    @abc.abstractmethod
    async def chat(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> str:
        """Return a single assistant reply string."""
        ...

    @abc.abstractmethod
    async def chat_stream(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
    ) -> AsyncGenerator[str, None]:
        """Yield string tokens as they arrive from the model."""
        ...

    @abc.abstractmethod
    async def extract(
        self,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 600,
    ) -> str:
        """
        Structured-extraction call (temperature=0).
        Returns the raw string response — callers parse JSON themselves.
        """
        ...

    @abc.abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Return embedding vector for text."""
        ...


# ─────────────────────────────────────────────────────────────────────────────
# OpenAI provider (original behaviour)
# ─────────────────────────────────────────────────────────────────────────────

class OpenAIProvider(BaseLLMProvider):
    """
    Wraps AsyncOpenAI with a singleton client.
    Behaviour is identical to the original llm_client.py.
    """

    def __init__(self, api_key: str, embedding_model: str, embedding_dimensions: int):
        from openai import AsyncOpenAI  # lazy import
        self._client = AsyncOpenAI(api_key=api_key)
        self._embedding_model = embedding_model
        self._embedding_dimensions = embedding_dimensions

    def _build_messages(
        self,
        system: str,
        user: str,
        recent_messages: list[dict] | None,
    ) -> list[dict]:
        messages: list[dict] = [{"role": "system", "content": system}]
        if recent_messages:
            for m in recent_messages[-10:]:
                role = m.get("role", "user")
                if role in ("user", "assistant"):
                    messages.append({"role": role, "content": m["content"]})
        messages.append({"role": "user", "content": user})
        return messages

    async def chat(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> str:
        messages = self._build_messages(system, user, recent_messages)
        response = await self._client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return response.choices[0].message.content.strip()

    async def chat_stream(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
    ) -> AsyncGenerator[str, None]:
        messages = self._build_messages(system, user, recent_messages)
        stream = await self._client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            stream=True,
        )
        async for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta

    async def extract(
        self,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 600,
    ) -> str:
        response = await self._client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_message},
            ],
            temperature=0,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content.strip()

    async def embed(self, text: str) -> list[float]:
        resp = await self._client.embeddings.create(
            model=self._embedding_model,
            input=text,
        )
        return resp.data[0].embedding


# ─────────────────────────────────────────────────────────────────────────────
# Anthropic provider
# ─────────────────────────────────────────────────────────────────────────────

class AnthropicProvider(BaseLLMProvider):
    """
    Uses the `anthropic` SDK.
    Default chat/extract model: claude-sonnet-4-20250514.
    Does NOT support native embeddings — embed() raises NotImplementedError
    so the factory falls back to OpenAIProvider for embeddings.
    """

    DEFAULT_MODEL = "claude-sonnet-4-20250514"

    def __init__(self, api_key: str):
        try:
            import anthropic  # lazy import — optional dependency
            self._client = anthropic.AsyncAnthropic(api_key=api_key)
        except ImportError as exc:
            raise ImportError(
                "anthropic package is required for AnthropicProvider. "
                "Install it: pip install anthropic>=0.25.0"
            ) from exc

    def _resolve_model(self, model: str) -> str:
        """
        Map OpenAI model names to Anthropic equivalents when the caller
        passes a model string from model_router (which still emits gpt-* names).
        """
        _MAP = {
            "gpt-4o":       "claude-opus-4-20250514",
            "gpt-4o-mini":  "claude-sonnet-4-20250514",
        }
        return _MAP.get(model, model if model.startswith("claude") else self.DEFAULT_MODEL)

    def _build_messages(
        self,
        user: str,
        recent_messages: list[dict] | None,
    ) -> list[dict]:
        messages: list[dict] = []
        if recent_messages:
            for m in recent_messages[-10:]:
                role = m.get("role", "user")
                if role in ("user", "assistant"):
                    messages.append({"role": role, "content": m["content"]})
        messages.append({"role": "user", "content": user})
        return messages

    async def chat(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> str:
        resolved = self._resolve_model(model)
        messages = self._build_messages(user, recent_messages)
        response = await self._client.messages.create(
            model=resolved,
            system=system,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return response.content[0].text.strip()

    async def chat_stream(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
    ) -> AsyncGenerator[str, None]:
        resolved = self._resolve_model(model)
        messages = self._build_messages(user, recent_messages)
        async with self._client.messages.stream(
            model=resolved,
            system=system,
            messages=messages,
            max_tokens=max_tokens,
        ) as stream:
            async for text in stream.text_stream:
                yield text

    async def extract(
        self,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 600,
    ) -> str:
        response = await self._client.messages.create(
            model=self.DEFAULT_MODEL,
            system=system_prompt,
            messages=[{"role": "user", "content": user_message}],
            max_tokens=max_tokens,
            temperature=0,
        )
        return response.content[0].text.strip()

    async def embed(self, text: str) -> list[float]:
        raise NotImplementedError(
            "Anthropic does not provide an embedding API. "
            "Use EMBEDDING_PROVIDER=openai (the default)."
        )


# ─────────────────────────────────────────────────────────────────────────────
# Gemini provider
# ─────────────────────────────────────────────────────────────────────────────

class GeminiProvider(BaseLLMProvider):
    """
    Uses google-generativeai SDK.
    Default chat/extract model: gemini-2.0-flash.
    Does NOT support native embeddings via this path — embed() raises
    NotImplementedError; factory falls back to OpenAIProvider for embeddings.
    """

    DEFAULT_MODEL = "gemini-2.0-flash"

    def __init__(self, api_key: str):
        try:
            import google.generativeai as genai  # lazy import
            genai.configure(api_key=api_key)
            self._genai = genai
        except ImportError as exc:
            raise ImportError(
                "google-generativeai package is required for GeminiProvider. "
                "Install it: pip install google-generativeai>=0.5.0"
            ) from exc

    def _resolve_model(self, model: str) -> str:
        _MAP = {
            "gpt-4o":      "gemini-2.0-flash",
            "gpt-4o-mini": "gemini-2.0-flash",
        }
        return _MAP.get(model, model if "gemini" in model else self.DEFAULT_MODEL)

    def _build_history(
        self,
        recent_messages: list[dict] | None,
    ) -> list[dict]:
        """Convert recent_messages to Gemini Content format."""
        history = []
        if recent_messages:
            for m in recent_messages[-10:]:
                role = m.get("role", "user")
                if role == "assistant":
                    role = "model"
                if role in ("user", "model"):
                    history.append({"role": role, "parts": [m["content"]]})
        return history

    async def chat(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> str:
        import asyncio
        resolved = self._resolve_model(model)
        gemini_model = self._genai.GenerativeModel(
            model_name=resolved,
            system_instruction=system,
        )
        history = self._build_history(recent_messages)
        chat_session = gemini_model.start_chat(history=history)
        # google-generativeai is sync — run in executor
        response = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: chat_session.send_message(
                user,
                generation_config=self._genai.types.GenerationConfig(
                    max_output_tokens=max_tokens,
                    temperature=temperature,
                ),
            )
        )
        return response.text.strip()

    async def chat_stream(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
    ) -> AsyncGenerator[str, None]:
        import asyncio
        resolved = self._resolve_model(model)
        gemini_model = self._genai.GenerativeModel(
            model_name=resolved,
            system_instruction=system,
        )
        history = self._build_history(recent_messages)
        chat_session = gemini_model.start_chat(history=history)
        response = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: chat_session.send_message(
                user,
                stream=True,
                generation_config=self._genai.types.GenerationConfig(
                    max_output_tokens=max_tokens,
                ),
            )
        )
        for chunk in response:
            if chunk.text:
                yield chunk.text

    async def extract(
        self,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 600,
    ) -> str:
        import asyncio
        gemini_model = self._genai.GenerativeModel(
            model_name=self.DEFAULT_MODEL,
            system_instruction=system_prompt,
        )
        response = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: gemini_model.generate_content(
                user_message,
                generation_config=self._genai.types.GenerationConfig(
                    max_output_tokens=max_tokens,
                    temperature=0,
                ),
            )
        )
        return response.text.strip()

    async def embed(self, text: str) -> list[float]:
        raise NotImplementedError(
            "GeminiProvider embedding not wired to pgvector-compatible dimensions. "
            "Use EMBEDDING_PROVIDER=openai (the default)."
        )


# ─────────────────────────────────────────────────────────────────────────────
# Ollama provider (local)
# ─────────────────────────────────────────────────────────────────────────────

class OllamaProvider(BaseLLMProvider):
    """
    Calls a local Ollama server via HTTP.
    Default base URL: http://localhost:11434
    Default model: llama3 (override via OLLAMA_CHAT_MODEL).

    Does NOT delegate embeddings — use OpenAI for embeddings (default).
    """

    def __init__(self, base_url: str, chat_model: str):
        import httpx  # lazy import — already a common dep
        self._base_url = base_url.rstrip("/")
        self._chat_model = chat_model
        self._http = httpx.AsyncClient(timeout=60.0)

    def _build_messages(
        self,
        system: str,
        user: str,
        recent_messages: list[dict] | None,
    ) -> list[dict]:
        messages: list[dict] = [{"role": "system", "content": system}]
        if recent_messages:
            for m in recent_messages[-10:]:
                role = m.get("role", "user")
                if role in ("user", "assistant"):
                    messages.append({"role": role, "content": m["content"]})
        messages.append({"role": "user", "content": user})
        return messages

    def _resolve_model(self, model: str) -> str:
        """Pass through Ollama model names; map gpt-* to configured model."""
        if model.startswith("gpt"):
            return self._chat_model
        return model

    async def chat(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> str:
        messages = self._build_messages(system, user, recent_messages)
        payload = {
            "model":    self._resolve_model(model),
            "messages": messages,
            "stream":   False,
            "options":  {"num_predict": max_tokens, "temperature": temperature},
        }
        resp = await self._http.post(f"{self._base_url}/api/chat", json=payload)
        resp.raise_for_status()
        return resp.json()["message"]["content"].strip()

    async def chat_stream(
        self,
        model: str,
        system: str,
        user: str,
        recent_messages: list[dict] | None = None,
        max_tokens: int = 1024,
    ) -> AsyncGenerator[str, None]:
        messages = self._build_messages(system, user, recent_messages)
        payload = {
            "model":    self._resolve_model(model),
            "messages": messages,
            "stream":   True,
            "options":  {"num_predict": max_tokens},
        }
        async with self._http.stream(
            "POST", f"{self._base_url}/api/chat", json=payload
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.strip():
                    try:
                        data = json.loads(line)
                        token = data.get("message", {}).get("content", "")
                        if token:
                            yield token
                        if data.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue

    async def extract(
        self,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 600,
    ) -> str:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_message},
        ]
        payload = {
            "model":    self._chat_model,
            "messages": messages,
            "stream":   False,
            "options":  {"num_predict": max_tokens, "temperature": 0},
        }
        resp = await self._http.post(f"{self._base_url}/api/chat", json=payload)
        resp.raise_for_status()
        return resp.json()["message"]["content"].strip()

    async def embed(self, text: str) -> list[float]:
        raise NotImplementedError(
            "OllamaProvider embeddings are not pgvector-dimension-compatible by default. "
            "Use EMBEDDING_PROVIDER=openai (the default)."
        )
