"""
embedding.service — Embedding wrapper.

Feature 1 upgrade vs before
-----------------------------
Previously: used AsyncOpenAI directly with an lru_cache client.
Now: delegates to get_embedding_provider().embed() from llm_factory.
The embedding provider always uses OpenAI text-embedding-3-small (the only
option compatible with the existing 1536-d pgvector column), but the call path
is now provider-abstracted for future flexibility.
cosine_similarity() is unchanged.
"""
from __future__ import annotations

import math

from loguru import logger

from src.services.llm_factory import get_embedding_provider


async def get_embedding(text: str) -> list[float]:
    """Return a 1536-d embedding vector for text."""
    text = text.strip().replace("\n", " ")
    if not text:
        raise ValueError("Cannot embed empty text")
    try:
        provider = get_embedding_provider()
        return await provider.embed(text)
    except Exception as exc:
        logger.error(f"Embedding error: {exc}")
        raise


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """
    Standard cosine similarity between two equal-length vectors.
    Returns value in [-1.0, 1.0].
    """
    if len(a) != len(b):
        raise ValueError("Vectors must have equal dimensions")
    dot    = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x ** 2 for x in a))
    norm_b = math.sqrt(sum(x ** 2 for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)
