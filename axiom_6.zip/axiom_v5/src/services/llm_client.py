"""
llm_client.py — Thin async wrapper for chat completions.

Feature 1 upgrade vs before
-----------------------------
Previously: hardcoded AsyncOpenAI singleton.
Now: delegates ALL calls to get_llm_provider() from llm_factory.
No call-site changes required — the public API (chat, chat_stream) is unchanged.
Switch providers via LLM_PROVIDER env var without touching this file.
"""
from __future__ import annotations

from typing import AsyncGenerator

from src.services.llm_factory import get_llm_provider


async def chat(
    model: str,
    system: str,
    user: str,
    recent_messages: list[dict] | None = None,
    max_tokens: int = 1024,
    temperature: float = 0.7,
) -> str:
    """
    Call the configured LLM provider for a single completion.
    recent_messages: list of {"role": "user"|"assistant", "content": str}
    Returns: assistant reply string.
    """
    provider = get_llm_provider()
    return await provider.chat(
        model=model,
        system=system,
        user=user,
        recent_messages=recent_messages,
        max_tokens=max_tokens,
        temperature=temperature,
    )


async def chat_stream(
    model: str,
    system: str,
    user: str,
    recent_messages: list[dict] | None = None,
    max_tokens: int = 1024,
) -> AsyncGenerator[str, None]:
    """
    Stream tokens from the configured LLM provider.
    Yields string tokens as they arrive.

    Feature 3 (Streaming) uses this method directly.
    """
    provider = get_llm_provider()
    async for token in provider.chat_stream(
        model=model,
        system=system,
        user=user,
        recent_messages=recent_messages,
        max_tokens=max_tokens,
    ):
        yield token
