from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # ── App ────────────────────────────────────────────────────────────────
    app_name: str = "Axiom Remember"
    app_version: str = "1.0.0"
    debug: bool = False

    # ── Database ───────────────────────────────────────────────────────────
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/axiom_remember"

    # ── OpenAI ─────────────────────────────────────────────────────────────
    openai_api_key: str
    embedding_model: str = "text-embedding-3-small"
    extraction_model: str = "gpt-4o-mini"
    summarization_model: str = "gpt-4o-mini"
    embedding_dimensions: int = 1536

    # ── Memory scoring ─────────────────────────────────────────────────────
    memory_decay_lambda: float = 0.05
    memory_decay_threshold: float = 0.15
    contradiction_threshold: float = 0.88

    importance_weights: dict = {
        "identity": 0.95,
        "goal":     0.80,
        "fact":     0.60,
        "preference": 0.50,
        "habit":    0.45,
        "constraint": 0.70,
        "event":    0.40,
    }

    # ── Short-term window ──────────────────────────────────────────────────
    short_term_window: int = 20
    context_top_memories: int = 10

    # ── Background jobs ────────────────────────────────────────────────────
    decay_job_interval: int = 3600
    summarize_job_interval: int = 21600
    cleanup_job_interval: int = 86400
    summarize_min_messages: int = 30
    cleanup_min_score: float = 0.15

    # ── Reinforcement ──────────────────────────────────────────────────────
    reinforcement_boost: float = 0.1

    # ── Model routing ──────────────────────────────────────────────────────
    complex_model: str = "gpt-4o"
    simple_model: str = "gpt-4o-mini"

    # ── Auth ───────────────────────────────────────────────────────────────
    admin_secret: str = "change-me-in-production"

    # ── Graph traversal ────────────────────────────────────────────────────
    graph_max_hops: int = 1
    graph_max_additions: int = 3
    graph_min_score: float = 0.20


    # ── LLM Provider (Feature 1) ───────────────────────────────────────────
    # openai (default) | anthropic | gemini | ollama
    llm_provider: str = "openai"
    anthropic_api_key: str = ""
    gemini_api_key: str = ""
    embedding_provider: str = "openai"        # always openai for pgvector compat
    ollama_base_url: str = "http://localhost:11434"
    ollama_chat_model: str = "llama3"

@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
