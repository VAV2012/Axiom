from loguru import logger
from sqlalchemy import select

from src.db.connection import AsyncSessionLocal
from src.db.models import Session
from src.services import summarization as summarization_svc


async def run_summarization_job() -> None:
    """Scheduled job: summarise sessions that have accumulated enough messages."""
    logger.info("[Job:Summarization] Starting...")
    async with AsyncSessionLocal() as db:
        try:
            stmt = select(Session).where(Session.is_closed == False)
            result = await db.execute(stmt)
            sessions = result.scalars().all()

            created = 0
            for session in sessions:
                summary = await summarization_svc.summarize_session(
                    db, session.user_id, session.id
                )
                if summary:
                    created += 1

            await db.commit()
            logger.info(f"[Job:Summarization] Done — {created} summaries created")
        except Exception as exc:
            await db.rollback()
            logger.error(f"[Job:Summarization] Failed: {exc}")
