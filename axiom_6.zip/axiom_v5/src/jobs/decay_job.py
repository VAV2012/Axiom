from loguru import logger
from src.db.connection import AsyncSessionLocal
from src.services import decay as decay_svc


async def run_decay_job() -> None:
    """Scheduled job: rescore all memories and archive weak ones."""
    logger.info("[Job:Decay] Starting...")
    async with AsyncSessionLocal() as db:
        try:
            stats = await decay_svc.run_decay(db)
            await db.commit()
            logger.info(f"[Job:Decay] Done — {stats}")
        except Exception as exc:
            await db.rollback()
            logger.error(f"[Job:Decay] Failed: {exc}")
