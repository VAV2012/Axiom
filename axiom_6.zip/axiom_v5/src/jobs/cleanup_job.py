from datetime import datetime, timezone, timedelta

from loguru import logger
from sqlalchemy import delete, and_

from src.db.connection import AsyncSessionLocal
from src.db.models import Memory


ARCHIVE_RETENTION_DAYS = 30


async def run_cleanup_job() -> None:
    """Scheduled job: hard-delete archived memories older than retention window."""
    logger.info("[Job:Cleanup] Starting...")
    cutoff = datetime.now(timezone.utc) - timedelta(days=ARCHIVE_RETENTION_DAYS)

    async with AsyncSessionLocal() as db:
        try:
            stmt = delete(Memory).where(
                and_(
                    Memory.is_archived == True,
                    Memory.updated_at < cutoff,
                )
            )
            result = await db.execute(stmt)
            await db.commit()
            logger.info(f"[Job:Cleanup] Deleted {result.rowcount} archived memories")
        except Exception as exc:
            await db.rollback()
            logger.error(f"[Job:Cleanup] Failed: {exc}")
